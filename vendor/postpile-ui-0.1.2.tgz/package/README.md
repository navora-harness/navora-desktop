# Postpile UI 可导入组件包

浏览器组件包 `@postpile/ui`，无框架运行时依赖。支持 Vite、Vue、React 等浏览器项目，也可以直接通过原生 ES Module 使用。入口不自动改造页面中的按钮或选择框；按需创建组件即可。服务端渲染项目请在客户端挂载后调用 DOM 相关方法。

## 安装和导入

在主项目运行 `npm run ui:pack`，生成 `artifacts/ui-package/postpile-ui-0.1.2.tgz`。其它项目安装：

```sh
npm install ./postpile-ui-0.1.2.tgz
```

```js
import '@postpile/ui/styles.css';
import { installPostpileUI, createButtonMenu, createInlineSearch, createInlineVolume } from '@postpile/ui';

const ui = installPostpileUI(document.querySelector('#app'));
const menu = createButtonMenu(triggerButton, menuElement);
const search = createInlineSearch(searchElement);
const volume = createInlineVolume(volumeElement);
// 页面卸载时释放各组件：menu.destroy(); search.destroy(); volume.destroy(); ui.destroy();
```

`installPostpileUI` 可选，仅安装按钮增强且重复调用不会重复注册；菜单和展开组件可单独使用。请在 DOM 已挂载时调用。Vue 使用 `onMounted` 创建、`onBeforeUnmount` 销毁；React 使用 `useEffect` 创建并返回清理函数。

`styles.css` 同时包含 Postpile 既有类名适配规则；已有项目可按需导入 `@postpile/ui/library/menu.css`、`inline-controls.css` 等，基础颜色由 `glass.css` 提供。主题使用 `<html data-theme="dark">`，浅色为 `data-theme="light"`。

需要自动适配既有 Postpile 标记（按钮、选择框和原生弹窗）时，额外 `import '@postpile/ui/auto'`。此兼容入口注册全页监听，应只在应用根入口加载一次。

无需构建工具的完整示例：`examples/import-ready.html`。解压包后通过本地 HTTP 服务打开，不能直接使用 `file://`。搜索/音量标记和方法详见 `docs/inline-controls.md`；菜单用法见 `docs/menus.md`。

---

# UI 库维护说明

统一存放 UI 库、可交互示例和风格文档。播放器控制面板沿用原实现，不纳入本次按钮替换。

## 目录

- `library/`：共享资源的维护源。`buttons.*` 是按钮样式、状态转场和类型声明；`glass.css` 是玻璃面板；`motion.css` 是媒体库动效；`forms.css` 是表单布局。
- `library/menu.js/css/d.ts`：从“更多”按钮展开的操作菜单，支持键盘、长列表及原生弹窗；用法见 `docs/menus.md`。
- `library/dialog-motion.js/d.ts`、`native-dialogs.js`：主程序与原生媒体库的按钮变形弹窗，支持占位、收回、减少动态效果和滚动管理。`menu-confirm.js/d.ts` 让已有确认在发起菜单内完成。
- `library/form-select.js`：产品与示例共用的自定义下拉框，保留原生 select 值与事件；Vue 通过 `src/components/AppSelect.vue` 适配。`vue.css` 统一 Vue 表单外观。
- `library/select-core.js`：可显式创建的筛选／下拉组合，支持 `auto`、`expanded`、`collapsed` 三种模式、图标＋文字、横向无滚动条浏览和边缘渐隐。展台“筛选与下拉”可切换宽窄栏体验，已通过 Vue 适配接入产品筛选与下拉框；用法见 `docs/choice-selects.md`。
- `examples/`：`index.html` 是可交互组件展示页，`gallery.css/js` 负责页面布局与演示适配，直接使用共享资源。另有表单、按钮快速切换和历史样式方案；`button-motion-v4.html` 由生成脚本从基础示例生成。
- `docs/`：按钮、弹窗、表单及动效规范。
- `scripts/serve.cjs`：本地预览服务；保留原有页面 URL。

## 预览与同步

在项目根目录运行 `npm run ui:preview`，打开终端给出的地址（默认端口 39853）。已有预览服务运行时可直接刷新页面。

修改 `library/` 中的正式资源后运行 `npm run ui:sync`，将资源同步到 `src/media-library/static/` 和 `media-manager/web/static/`。这两个位置是产品需要的镜像，请勿分别维护。`npm run ui:check` 检查镜像是否一致。开发及构建前也会自动同步 UI 库到主程序资源目录。

独立仓库 `D:/electron/postpile-media-library-private` 使用 `npm run ui:sync:standalone` 同步共享资源和公共弹窗标记，`npm run ui:check:standalone` 校验。可通过 `-- --target <repo>` 指定其它工作区。脚本保留独立设置、后端和播放器内联脚本；播放器逻辑变更仍需针对差异合并，不能声称此脚本同步全部媒体库。Vue 弹窗标题适配组件继续位于 `src/components/AppDialogHeader.vue`，不复制第二份实现。完整流程见根目录 `HANDOFF.md`。

## 检查

- `scripts/preview-form-design.cjs`：桌面/窄屏表单、下拉框开合、字体和位置衔接、悬停清除、保存按钮高度与横向位置。
- `scripts/preview-app-buttons.cjs`：实际 Vue/Vuetify 与原生按钮、加载中断、动画层复用、占位、对比度、减少动态效果和资源释放。
- `scripts/preview-ui-library.cjs`：全部示例入口、快速状态切换、最多两层及窄屏布局。
- `scripts/preview-ui-gallery.cjs`：组件展台、按钮颜色交接、稳定占位与增长、弹窗、菜单、提示、主题和窄屏。
- `scripts/preview-dialog-header.cjs`：真实 Vue 弹窗标题组件的副标题、辅助操作和关闭图标对齐。
- `scripts/preview-app-select.cjs`：真实 Vue 选择框的数值/字符串模型、异步选项、禁用、卸载清理、实际定时输入及原生模态弹窗点击。
- `scripts/preview-dropdown-scroll.cjs`：36 项长列表、限高、原生滚轮、细滚动条和选中项可见性。
- `scripts/build-button-motion-preview.cjs`：重新生成历史 V4 对照示例。

示例中的加载与保存是演示状态，不会改动媒体库数据。按钮实验仅通过外部状态控件打断视觉转场；业务请求是否允许取消，仍由调用方决定。
