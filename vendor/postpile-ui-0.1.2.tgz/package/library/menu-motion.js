/* Surface-only adapter for existing menu controllers. Does not own actions/focus. */
import {animateDialogSurface} from './dialog-motion.js';
const pageMotions=new WeakMap();
export function animateMenuPageChange(panel,from,contents,title,origin){
 pageMotions.get(panel)?.();
 if(matchMedia('(prefers-reduced-motion: reduce)').matches)return [];
 const rect=panel.getBoundingClientRect(),top=Math.max(Math.min(12,from.top),Math.min(from.top,innerHeight-rect.height-12));panel.style.top=top+'px';
 panel.scrollTop=0;panel.setAttribute('data-pp-menu-page-motion','');
 const cleanup=()=>{if(pageMotions.get(panel)!==cleanup)return;pageMotions.delete(panel);panel.removeAttribute('data-pp-menu-page-motion')};
 pageMotions.set(panel,cleanup);
 const timing={duration:280,easing:'cubic-bezier(.22,.75,.2,1)'};
 const animations=[panel.animate([{left:from.left+'px',top:from.top+'px',height:from.height+'px'},{left:rect.left+'px',top:top+'px',height:rect.height+'px'}],timing)];
 for(const content of Array.isArray(contents)?contents:[contents])if(content){const opacity=getComputedStyle(content).opacity;animations.push(content.animate([{opacity:0,transform:'translateX(12px)',filter:'blur(2px)'},{opacity,transform:'translateX(0px)',filter:'blur(0px)'}],{duration:280,easing:'cubic-bezier(.22,.75,.2,1)'}))}
 if(title&&origin){const target=title.getBoundingClientRect();animations.push(title.animate([{transform:`translate(${origin.left-target.left}px,${origin.top-target.top}px)`},{transform:'translate(0px,0px)'}],timing))}
 animations[0].finished.then(cleanup,cleanup);
 return animations;
}
export function animateMenuLabelReturn(button,from){
 if(!button||!from||matchMedia('(prefers-reduced-motion: reduce)').matches)return null;
 let label=button.querySelector('.menubar-option__label,.pp-menu-label,.pp-return-label');
 if(!label){label=document.createElement('span');label.className='pp-return-label';const nodes=[...button.childNodes].filter(node=>node.nodeType===Node.TEXT_NODE&&node.textContent.trim());if(!nodes.length)return null;nodes[0].before(label);label.append(...nodes)}
 const to=label.getBoundingClientRect();
 return label.animate([{transform:`translate(${from.left-to.left}px,${from.top-to.top}px)`},{transform:'translate(0px,0px)'}],{duration:280,easing:'cubic-bezier(.22,.75,.2,1)'});
}
export function animateMenuSurface(el,anchor,opening,done=()=>{}){
 let cancelled=false,frame=0,cancelMotion=()=>{},attempts=0;
 if(opening)el.setAttribute('data-pp-menu-pending','');
 function start(){
  if(cancelled)return;
  const rect=el.getBoundingClientRect();
  if((!rect.width||!rect.height)&&el.isConnected&&++attempts<10){frame=requestAnimationFrame(start);return}
  cancelMotion=animateDialogSurface(el,anchor,opening,done,{duration:380,menu:true});
  el.removeAttribute('data-pp-menu-pending');
 }
 frame=requestAnimationFrame(start);
 return ()=>{cancelled=true;cancelAnimationFrame(frame);cancelMotion();el.removeAttribute('data-pp-menu-pending')};
}
