/* Shared motion; callers retain visibility, actions and focus. */
let lastButton=null,lastTime=0;
const running=new WeakMap(),sources=new WeakMap(),anchorLocks=new WeakMap();
for(const [name,syntax,initialValue] of [['--pp-dialog-radius','<length-percentage>','22px'],['--pp-dialog-fill','<color>','transparent'],['--pp-shadow-progress','<number>','0']]){try{CSS.registerProperty({name,syntax,inherits:false,initialValue})}catch(_){}}
if(typeof document!=='undefined')document.addEventListener('click',event=>{const button=event.target instanceof Element?event.target.closest('button,summary'):null;if(button){lastButton=button;lastTime=performance.now()}},true);
export function dialogAnchor(){return performance.now()-lastTime<1000&&lastButton?.isConnected?lastButton:null}
// WebKit drops layout interpolation when a surface also has animated registered
// custom properties, even in a separate animation on that same element.
export function surfaceGeometryFrames(frames){return frames.map(frame=>Object.fromEntries(Object.entries(frame).filter(([key])=>!key.startsWith('--'))))}
export function animateSurface(el,frames,timing){
 const properties=[...new Set(frames.flatMap(frame=>Object.keys(frame).filter(key=>key.startsWith('--'))))];
 if(!properties.length)return el.animate(frames,timing);
 const saved=properties.map(key=>[key,el.style.getPropertyValue(key),el.style.getPropertyPriority(key)]);
 const material=document.createElement('span');material.setAttribute('aria-hidden','true');material.setAttribute('data-pp-motion-material','');
 material.style.cssText='position:fixed;width:0;height:0;visibility:hidden;pointer-events:none;contain:strict';
 document.body.append(material);
 const materialFrames=frames.map(frame=>Object.fromEntries(Object.entries(frame).filter(([key])=>key.startsWith('--')||['offset','easing','composite'].includes(key))));
 const paint=material.animate(materialFrames,timing);paint.pause();paint.currentTime=0;
 const animation=el.animate(surfaceGeometryFrames(frames),timing);
 let frame=0,disposed=false;
 function apply(){
  if(disposed)return;
  paint.currentTime=animation.currentTime??0;
  const css=getComputedStyle(material);
  properties.forEach(key=>el.style.setProperty(key,css.getPropertyValue(key)));
  frame=requestAnimationFrame(apply);
 }
 function cleanup(){
  if(disposed)return;disposed=true;cancelAnimationFrame(frame);paint.cancel();material.remove();
  saved.forEach(([key,value,priority])=>value?el.style.setProperty(key,value,priority):el.style.removeProperty(key));
 }
 const cancel=animation.cancel.bind(animation);
 animation.cancel=()=>{cleanup();cancel()};
 animation.finished.then(cleanup,cleanup);
 apply();
 return animation;
}
// Keep host !important shadows under the same interpolated progress as the surface.
export function prepareSurfaceShadow(el,from,to){
 const saved=['box-shadow','--pp-shadow-progress'].map(key=>[key,el.style.getPropertyValue(key),el.style.getPropertyPriority(key)]);
 const fade=(shadow,weight)=>!shadow||shadow==='none'?'':shadow.replace(/(?:rgba?|color|oklab|oklch|lab|lch)\([^)]*\)/g,color=>`color-mix(in srgb, ${color} calc((${weight}) * 100%), transparent)`);
 const value=[fade(from,'1 - var(--pp-shadow-progress)'),fade(to,'var(--pp-shadow-progress)')].filter(Boolean).join(', ')||'none';
 el.style.setProperty('box-shadow',value,'important');el.style.setProperty('--pp-shadow-progress','0');
 return ()=>saved.forEach(([key,value,priority])=>value?el.style.setProperty(key,value,priority):el.style.removeProperty(key));
}
export function freezeSurfacePosition(el,box){
 Object.assign(el.style,{position:'fixed',left:'0px',top:'0px',right:'auto',bottom:'auto',margin:'0',width:box.width+'px',height:box.height+'px'});
 const origin=el.getBoundingClientRect();
 const left=box.left-origin.left,top=box.top-origin.top;
 Object.assign(el.style,{left:left+'px',top:top+'px'});
 return {left:left+'px',top:top+'px'};
}
function restoreSource(el){const state=sources.get(el);if(!state)return;sources.delete(el);if(--state.lock.count)return;if(state.anchor.isConnected){if(state.lock.value)state.anchor.style.setProperty('opacity',state.lock.value,state.lock.priority);else state.anchor.style.removeProperty('opacity')}anchorLocks.delete(state.anchor)}
export function animateDialogSurface(el,anchor,opening,done=()=>{},options={}){
 running.get(el)?.();
 el.setAttribute('data-pp-surface','');
 const valid=anchor?.isConnected&&anchor.getClientRects().length;
 if(valid&&!sources.has(el)){let lock=anchorLocks.get(anchor);if(!lock){lock={value:anchor.style.getPropertyValue('opacity'),priority:anchor.style.getPropertyPriority('opacity'),count:0};anchorLocks.set(anchor,lock)}lock.count++;sources.set(el,{anchor,lock})}
 if(valid)anchor.style.setProperty('opacity','0','important');
 const complete=()=>{if(!opening)restoreSource(el);done()};
 if(matchMedia('(prefers-reduced-motion: reduce)').matches){complete();return ()=>restoreSource(el)}
 const box=el.getBoundingClientRect();
 if(!box.width||!box.height){restoreSource(el);done();return ()=>{}}
 const css=getComputedStyle(el),keys=['overflow','min-width','min-height','max-width','max-height','height','width','transform-origin','pointer-events','border-radius','background-color','box-shadow','position','left','top','right','bottom','margin','box-sizing','padding'];
 const saved=keys.map(key=>[key,el.style.getPropertyValue(key),el.style.getPropertyPriority(key)]);
 const children=[...el.children],childKeys=['width','height','min-width','min-height','max-width','max-height','flex-basis','flex-shrink'];
 const childStyles=children.map(child=>childKeys.map(key=>[key,child.style.getPropertyValue(key),child.style.getPropertyPriority(key)]));
 // Capture each child's own fractional layout before changing the parent box.
 // clientWidth rounds and can change text wrapping when the freeze is released.
 const childWidths=children.map(child=>{const rect=child.getBoundingClientRect(),style=getComputedStyle(child);return Math.max(0,rect.width-(style.boxSizing==='border-box'?0:['paddingLeft','paddingRight','borderLeftWidth','borderRightWidth'].reduce((sum,key)=>sum+(parseFloat(style[key])||0),0)))});
 const childHeights=children.map(child=>{const rect=child.getBoundingClientRect(),style=getComputedStyle(child);return Math.max(0,rect.height-(style.boxSizing==='border-box'?0:['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth'].reduce((sum,key)=>sum+(parseFloat(style[key])||0),0)))});
 Object.assign(el.style,{boxSizing:'border-box',overflow:'hidden',minWidth:'0',minHeight:'0',maxHeight:'none',width:box.width+'px',height:box.height+'px',transformOrigin:'top left'});
 el.style.setProperty('max-width','none','important');el.style.setProperty('overflow','hidden','important');el.setAttribute('data-pp-dialog-motion','');
 const position=freezeSurfacePosition(el,box);
 if(!opening)el.style.pointerEvents='none';
 // Freeze both axes, including flex basis and percentage constraints. Otherwise
 // the card's scrollport shrinks with its parent, adds a temporary scrollbar,
 // and gives that scrollbar's width back to the text at the final handoff.
 children.forEach((child,i)=>{for(const [key,value] of [['width',childWidths[i]+'px'],['height',childHeights[i]+'px'],['min-width','0px'],['min-height','0px'],['max-width','none'],['max-height','none'],['flex-basis','auto'],['flex-shrink','0']])child.style.setProperty(key,value,'important')});
 const sourceCss=valid?getComputedStyle(anchor):null,button=valid?anchor.getBoundingClientRect():null;
 const restoreShadow=prepareSurfaceShadow(el,sourceCss?.boxShadow||'none',css.boxShadow);
 const full={'--pp-shadow-progress':1,...position,width:box.width+'px',height:box.height+'px',padding:css.padding,transform:'translate3d(0px,0px,0px)',opacity:1,'--pp-dialog-radius':css.borderRadius,'--pp-dialog-fill':css.backgroundColor};
 const small=valid?{'--pp-shadow-progress':0,...position,width:button.width+'px',height:button.height+'px',padding:'0px',transform:'translate3d('+(button.left-box.left)+'px,'+(button.top-box.top)+'px,0px)',opacity:1,'--pp-dialog-radius':sourceCss.borderRadius,'--pp-dialog-fill':sourceCss.backgroundColor}:{...full,'--pp-shadow-progress':0,transform:'translateY(8px) scale(.975)',opacity:0};
 el.style.setProperty('border-radius','var(--pp-dialog-radius)','important');el.style.setProperty('background-color','var(--pp-dialog-fill)','important');
 let face;
 if(valid){
  // Keep the original tag/classes so Vuetify grid areas, content alignment and
  // scoped typography also apply to the return face.
  face=anchor.cloneNode(false);face.removeAttribute('id');face.removeAttribute('data-dialog-origin');face.removeAttribute('data-pp-button-visual');face.style.removeProperty('opacity');face.setAttribute('data-pp-dialog-face','');face.setAttribute('aria-hidden','true');face.setAttribute('tabindex','-1');face.inert=true;
  face.append(...[...anchor.childNodes].filter(node=>!(node instanceof Element&&node.classList.contains('pp-button-face'))).map(node=>node.cloneNode(true)));
  Object.assign(face.style,{position:'absolute',left:-(parseFloat(css.borderLeftWidth)||0)+'px',top:-(parseFloat(css.borderTopWidth)||0)+'px',margin:'0',minWidth:'0',maxWidth:'none',minHeight:'0',maxHeight:'none',flex:'none',boxSizing:'border-box',display:sourceCss.display,alignItems:sourceCss.alignItems,alignContent:sourceCss.alignContent,justifyItems:sourceCss.justifyItems,justifyContent:sourceCss.justifyContent,gridTemplateAreas:sourceCss.gridTemplateAreas,gridTemplateColumns:sourceCss.gridTemplateColumns,gridTemplateRows:sourceCss.gridTemplateRows,gap:sourceCss.gap,font:sourceCss.font,letterSpacing:sourceCss.letterSpacing,textTransform:sourceCss.textTransform,color:sourceCss.color,padding:sourceCss.padding,width:button.width+'px',height:button.height+'px',border:sourceCss.border,background:sourceCss.background,borderRadius:sourceCss.borderRadius,boxShadow:sourceCss.boxShadow,whiteSpace:'nowrap',pointerEvents:'none',zIndex:'3'});
  for(const [key,value] of [['transform','none'],['translate','none'],['scale','1'],['transition','none'],['animation','none']])face.style.setProperty(key,value,'important');
  face.querySelectorAll('[id]').forEach(node=>node.removeAttribute('id'));el.append(face);
 }
 const timing={duration:options.duration??(opening?440:380),easing:'cubic-bezier(.22,.75,.2,1)',fill:'both'};
 const bodyFrames=opening?[{opacity:0,filter:'blur(3px)'},{opacity:1,filter:'blur(0px)',offset:.55},{opacity:1,filter:'blur(0px)'}]:[{opacity:1,filter:'blur(0px)'},{opacity:0,filter:'blur(2px)',offset:options.menu ? .3 : .32},{opacity:0,filter:'blur(0px)',offset:.5},{opacity:0,filter:'blur(0px)'}];
 const animations=[animateSurface(el,opening?[small,full]:[full,small],timing),...children.map(child=>child.animate(bodyFrames,{...timing,easing:'linear'}))];
 if(face)animations.push(face.animate(opening?[{opacity:1},{opacity:0,offset:.3},{opacity:0}]:[{opacity:0},{opacity:0,offset:options.menu ? .4 : .45},{opacity:1,offset:options.menu ? .8 : .88},{opacity:1}],{...timing,easing:'linear'}));
 let settled=false,followFrame=0;
 // Toolbar layouts can move the source while the panel is returning to it.
 // Retarget the existing animation rather than restarting its clock.
 function followAnchor(){
  if(settled||opening||!valid||!anchor.isConnected)return;
  const target=anchor.getBoundingClientRect();
  if(target.width&&target.height){
   const destination={...small,width:target.width+'px',height:target.height+'px',transform:'translate3d('+(target.left-box.left)+'px,'+(target.top-box.top)+'px,0px)'};
   animations[0].effect.setKeyframes(surfaceGeometryFrames([full,destination]));
   if(face){face.style.width=target.width+'px';face.style.height=target.height+'px'}
  }
  followFrame=requestAnimationFrame(followAnchor);
 }
 if(!opening&&valid)followFrame=requestAnimationFrame(followAnchor);
 function cleanup(release=false){if(settled)return;settled=true;cancelAnimationFrame(followFrame);window.removeEventListener('resize',resize);visualViewport?.removeEventListener('resize',resize);animations.forEach(a=>a.cancel());restoreShadow();face?.remove();el.removeAttribute('data-pp-dialog-motion');saved.forEach(([key,value,priority])=>value?el.style.setProperty(key,value,priority):el.style.removeProperty(key));children.forEach((child,i)=>childStyles[i].forEach(([key,value,priority])=>value?child.style.setProperty(key,value,priority):child.style.removeProperty(key)));if(release)restoreSource(el);running.delete(el)}
 const viewport=()=>[innerWidth,innerHeight,visualViewport?.width,visualViewport?.height,visualViewport?.scale],initialViewport=viewport();
 const touchViewport=matchMedia('(pointer: coarse)').matches;
 function resize(){
  const current=viewport();
  // Mobile browser chrome and the keyboard animate viewport height themselves.
  // Finishing on every height event turns the surface morph into an instant jump.
  // Keep its frozen geometry until completion; normal layout then fits the new height.
  const indices=touchViewport?[0,2,4]:[0,1,2,3,4];
  if(indices.every(index=>current[index]===initialViewport[index]||Math.abs(current[index]-initialViewport[index])<(index===4?.001:1)))return;
  cleanup();complete();
 }
 const cancel=()=>{cleanup(true);restoreSource(el)};running.set(el,cancel);window.addEventListener('resize',resize);visualViewport?.addEventListener('resize',resize);
 animations[0].finished.then(()=>{if(settled)return;cleanup();complete()}).catch(()=>{});
 return cancel;
}


