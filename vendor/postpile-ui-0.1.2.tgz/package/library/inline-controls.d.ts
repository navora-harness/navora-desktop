export {};
declare global {
 interface Window {PostpileInlineControls:{animateLayout(elements:HTMLElement[],change:()=>void,options?:{immediate?:boolean;duration?:number}):()=>void;createSearch(root:HTMLElement):InlineControl;createVolume(root:HTMLElement):InlineControl}}
 interface InlineControl {open():void;close():void;toggle():void;readonly isOpen:boolean;destroy():void}
}
