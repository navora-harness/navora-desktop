import {installGlassButtons} from './buttons-core.js';
export {installGlassButtons};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>installGlassButtons(),{once:true});
else installGlassButtons();
