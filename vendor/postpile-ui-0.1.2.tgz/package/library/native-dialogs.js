import {animateDialogSurface,dialogAnchor} from './dialog-motion.js';
const states=new WeakMap();
export function openNativeDialog(dialog,anchor=dialogAnchor()){
 dialog.showModal();states.set(dialog,{anchor,cancel:animateDialogSurface(dialog,anchor,true)});
}
export function closeNativeDialog(dialog,finish){
 const state=states.get(dialog);if(state?.closing)return;state?.cancel?.();
 const next={anchor:state?.anchor,closing:true};states.set(dialog,next);
 next.cancel=animateDialogSurface(dialog,next.anchor,false,()=>{states.delete(dialog);finish()});
}
// Legacy overlays retain their existing visibility and business controllers.
export function installNativeDialogs(){
 function update(modal){
  const visible=!modal.classList.contains('hidden'),previous=states.get(modal);
  if(visible===previous?.visible)return;
  previous?.cancel?.();
  const surface=modal.querySelector('.modal-box');if(!surface)return;
  const state={visible,anchor:visible?dialogAnchor():previous?.anchor};states.set(modal,state);
  if(!visible&&!previous)return;
  if(!visible){modal.style.setProperty('display','flex','important');modal.style.pointerEvents='none';modal.setAttribute('data-pp-dialog-closing','')}
  else {modal.style.removeProperty('display');modal.style.removeProperty('pointer-events');modal.removeAttribute('data-pp-dialog-closing')}
  state.cancel=animateDialogSurface(surface,state.anchor,visible,()=>{if(!visible){modal.style.removeProperty('display');modal.style.removeProperty('pointer-events');modal.removeAttribute('data-pp-dialog-closing')}});
 }
 const observer=new MutationObserver(records=>{for(const record of records){if(record.target instanceof Element&&record.target.matches('.modal-overlay'))update(record.target)}});
 observer.observe(document.body,{subtree:true,attributes:true,attributeFilter:['class']});
 document.querySelectorAll('.modal-overlay:not(.hidden)').forEach(update);
}
