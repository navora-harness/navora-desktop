/* One observer for Vue, remote and standalone buttons. Native nodes and handlers
   stay intact. Animation layers exist only during state changes and loading. */
const selector='button.v-btn,a.v-btn,button.btn-icon,button.author-more-info,.titlebar button.icon-btn,.titlebar button.layout-btn,.modal-actions button,button.modal-close,.index-actions button,.selection-bar button,.work-selection-bar button,.settings-footer-actions button,.source-list-head>button,.source-directory-field>button,.settings-panel>.actions>button,.settings-panel>button,button.settings-close';
const excluded='.viewer,.v-tab,.v-btn-toggle,.v-pagination,.v-date-picker,.v-bottom-navigation,.web-bottom-nav,[data-button-motion="off"],[data-pp-dialog-face]';
const spinner='<svg class="pp-button-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8" opacity=".18"/><path d="M12 4a8 8 0 0 1 8 8"/></svg>';

export function installGlassButtons(root=document){
  const states=new WeakMap(),faces=new WeakMap(),active=new Set(),reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const eligible=button=>button instanceof HTMLElement&&button.matches(selector)&&!button.closest(excluded);
  function contents(button){
    const content=button.querySelector(':scope > .v-btn__content');
    if(content)return [...button.querySelectorAll(':scope > .v-btn__prepend,:scope > .v-btn__content,:scope > .v-btn__append')].map(node=>node.innerHTML).join('');
    return Array.from(button.childNodes).filter(node=>!(node instanceof Element&&node.classList.contains('pp-button-face'))).map(node=>node.nodeType===Node.TEXT_NODE?escapeText(node.textContent||''):node.outerHTML||'').join('');
  }
  function escapeText(value){const span=document.createElement('span');span.textContent=value;return span.innerHTML}
  function layoutSize(button,css=getComputedStyle(button)){
    if(!button.getClientRects().length)return {width:0,height:0};
    const extra=axis=>css.boxSizing==='border-box'?0:(axis==='width'?['paddingLeft','paddingRight','borderLeftWidth','borderRightWidth']:['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth']).reduce((sum,key)=>sum+(parseFloat(css[key])||0),0);
    return {width:(parseFloat(css.width)||button.offsetWidth-extra('width'))+extra('width'),height:(parseFloat(css.height)||button.offsetHeight-extra('height'))+extra('height')};
  }
  function fixedLayout(state){return state.button.dataset.buttonMotionLayout==='fixed'}
  function holdWidth(state,width){
    if(fixedLayout(state))return;
    const css=getComputedStyle(state.button),extra=css.boxSizing==='border-box'?0:['paddingLeft','paddingRight','borderLeftWidth','borderRightWidth'].reduce((sum,key)=>sum+(parseFloat(css[key])||0),0);
    state.button.style.width=Math.max(0,width-extra)+'px';
  }
  function finalOffset(state){
    // Layout may align the final, narrower label to either edge of its slot.
    // Move the face to that center before restoring the natural button width.
    const button=state.button,heldWidth=button.style.width;
    button.style.width=state.savedWidth;
    const target=button.getBoundingClientRect();
    button.style.width=heldWidth;
    const slot=button.getBoundingClientRect(),scale=slot.width/layoutSize(button).width||1;
    return (target.left+target.width/2-slot.left-slot.width/2)/scale;
  }
  function snapshot(button,previous){
    const visual=button.hasAttribute('data-pp-button-visual');
    if(visual)setVisual(button,false);
    const css=getComputedStyle(button),busy=button.classList.contains('v-btn')?button.classList.contains('v-btn--loading'):button.getAttribute('aria-busy')==='true';
    const html=contents(button),pressed=button.getAttribute('aria-pressed')||'';
    const result={busy,html,signature:JSON.stringify([busy,html,pressed]),...layoutSize(button,css),
      color:css.color,
      fill:css.getPropertyValue('--pp-button-fill'),edge:css.getPropertyValue('--pp-button-edge'),shadow:css.getPropertyValue('--pp-button-shadow'),radius:css.borderRadius};
    if(visual)setVisual(button,true);
    return result;
  }
  function cancel(animation){animation.cancel();animation.effect=null}
  function setVisual(button,visible){
    // The faces own the crossfade. Suppress the root's unrelated hover/color
    // transition while handing the identical material to or from those faces.
    const value=button.style.getPropertyValue('transition'),priority=button.style.getPropertyPriority('transition');
    button.style.setProperty('transition','none','important');
    button.toggleAttribute('data-pp-button-visual',visible);
    void getComputedStyle(button).backgroundColor;
    if(value)button.style.setProperty('transition',value,priority);else button.style.removeProperty('transition');
  }
  function clear(state){
    state.epoch=(state.epoch||0)+1;
    state.animations.forEach(cancel);state.animations=[];
    state.face?.remove();state.leaving?.remove();state.face=null;state.leaving=null;
    setVisual(state.button,false);
    if(state.savedWidth!==null){state.button.style.width=state.savedWidth;state.savedWidth=null}
    active.delete(state);
  }
  function face(state,snap){
    const node=document.createElement('span');node.className='pp-button-face';node.setAttribute('aria-hidden','true');node.inert=true;
    Object.assign(node.style,{width:(snap.busy?snap.height:snap.width)+'px',height:snap.height+'px',color:snap.color,background:snap.fill,border:'1px solid '+snap.edge,boxShadow:snap.shadow,borderRadius:snap.busy?'50%':snap.radius});
    node.innerHTML=snap.busy?spinner:snap.html;
    node.querySelectorAll('[id]').forEach(child=>child.removeAttribute('id'));
    faces.set(node,snap);state.button.append(node);return node;
  }
  function swap(state,next){
    const previous=state.snapshot;state.snapshot=next;
    if(!previous.width){previous.width=next.width;previous.height=next.height}
    if(reduced.matches||document.hidden||!next.width||!next.height){clear(state);if(next.busy)holdBusy(state,next);return}
    const epoch=state.epoch=(state.epoch||0)+1;
    const layers=[state.face,state.leaving].filter(Boolean);
    if(!layers.length)layers.push(face(state,previous));
    for(const layer of layers)if(layer.parentElement!==state.button)state.button.append(layer);
    const read=layer=>{const css=getComputedStyle(layer);return {opacity:css.opacity,scale:css.scale==='none'?'1':css.scale,filter:css.filter==='none'?'blur(0px)':css.filter,width:css.width,transform:css.transform}};
    const captured=new Map(layers.map(layer=>[layer,read(layer)]));
    const fixed=fixedLayout(state);
    const currentSlot=fixed||state.animations.length?layoutSize(state.button).width:previous.width;
    const returning=layers.find(layer=>{const snap=faces.get(layer);return next.busy?snap?.busy:snap?.signature===next.signature});
    const old=layers.filter(layer=>layer!==returning).sort((a,b)=>+captured.get(b).opacity-+captured.get(a).opacity)[0];
    const from=old?captured.get(old):null;
    state.animations.forEach(cancel);
    layers.filter(layer=>layer!==old&&layer!==returning).forEach(layer=>layer.remove());state.animations=[];state.leaving=old||null;
    if(state.savedWidth===null){state.savedWidth=state.button.style.width;holdWidth(state,previous.width)}
    // Keep the widest label's slot across result changes. Larger labels grow
    // the slot in the same transition; shorter labels never move neighbours.
    const slotBefore=currentSlot;
    const slotWidth=state.slotWidth=fixed?currentSlot:Math.max(state.slotWidth||0,slotBefore,next.busy?previous.width:next.width);
    const rootCss=getComputedStyle(state.button),extra=rootCss.boxSizing==='border-box'?0:['paddingLeft','paddingRight','borderLeftWidth','borderRightWidth'].reduce((sum,key)=>sum+(parseFloat(rootCss[key])||0),0);
    if(!fixed)state.button.style.minWidth=Math.max(0,slotWidth-extra)+'px';
    next.width=slotWidth;
    setVisual(state.button,true);
    const incoming=returning||face(state,next);state.face=incoming;active.add(state);
    incoming.style.color=next.color;
    const offset=next.busy||fixed?0:finalOffset(state);
    const start=returning?captured.get(returning):{opacity:0,scale:'.6',filter:'blur(5px)',transform:from?.transform||'translateX(0px)',width:(next.busy?next.height:from?parseFloat(from.width):previous.width)+'px'};
    const options={duration:returning?Math.max(120,400*(1-Number(start.opacity))):400,easing:'cubic-bezier(.22,.75,.2,1)',fill:'forwards'};
    const leaving=old?.animate([from,{opacity:0,scale:'.72',filter:'blur(5px)',transform:`translateX(${offset}px)`,width:(next.busy?next.height:previous.busy?parseFloat(from.width):next.width)+'px'}],options);
    const entering=incoming.animate([start,{opacity:1,scale:'1',filter:'blur(0px)',transform:`translateX(${offset}px)`,width:(next.busy?next.height:next.width)+'px'}],options);
    const layout=!fixed&&slotWidth>slotBefore+.1?state.button.animate([{minWidth:Math.max(0,slotBefore-extra)+'px'},{minWidth:Math.max(0,slotWidth-extra)+'px'}],options):null;
    state.animations=[leaving,entering,layout].filter(Boolean);
    Promise.allSettled(state.animations.map(animation=>animation.finished)).then(()=>{
      if(state.epoch!==epoch||state.face!==incoming)return;
      old?.remove();state.leaving=null;state.animations.forEach(cancel);state.animations=[];
      if(!state.snapshot.busy)clear(state);
    });
  }
  function holdBusy(state,snap){
    if(state.savedWidth===null){state.savedWidth=state.button.style.width;holdWidth(state,snap.width)}
    setVisual(state.button,true);state.face=face(state,snap);active.add(state);
  }
  function update(button){
    if(!eligible(button))return;
    if(!button.classList.contains('pp-glass-button'))button.classList.add('pp-glass-button');
    const state=states.get(button),next=snapshot(button,state?.snapshot);
    if(!state){const initial={button,snapshot:next,face:null,leaving:null,animations:[],savedWidth:null};states.set(button,initial);if(next.busy)holdBusy(initial,next);return}
    if(next.signature===state.snapshot.signature){if(!state.face)state.snapshot=next;return}
    if(state.savedWidth!==null){
      // Measure the new label at its natural width before animating to it.
      // Reusing the loading placeholder width causes a jump at layer removal.
      const heldWidth=button.style.width;
      button.style.width=state.savedWidth;
      Object.assign(next,layoutSize(button));
      button.style.width=heldWidth;
    }
    if(state.snapshot.busy&&next.busy&&state.face){
      state.snapshot=next;
      // Progress labels may update or replace native textContent repeatedly.
      // Keep one continuous spinner instead of restarting the entrance each time.
      for(const layer of [state.leaving,state.face])if(layer&&layer.parentElement!==button)button.append(layer);
      return;
    }
    swap(state,next);
  }
  function visit(node,callback){if(!(node instanceof Element))return;if(node.matches(selector))callback(node);node.querySelectorAll(selector).forEach(callback)}
  const observer=new MutationObserver(records=>{
    const pending=new Set();
    for(const record of records){
      if(record.target instanceof Element&&record.target.closest('.pp-button-face'))continue;
      if(record.type==='childList'){
        const nodes=[...record.addedNodes,...record.removedNodes];
        if(nodes.length&&nodes.every(node=>node instanceof Element&&node.classList.contains('pp-button-face')))continue;
        record.removedNodes.forEach(node=>visit(node,button=>{if(!button.isConnected){const state=states.get(button);if(state)clear(state);states.delete(button)}}));
        record.addedNodes.forEach(node=>visit(node,button=>pending.add(button)));
      }
      const target=record.target instanceof Element?record.target:record.target.parentElement;
      const button=target?.closest(selector);if(button)pending.add(button);
    }
    pending.forEach(update);
  });
  root.querySelectorAll(selector).forEach(update);
  observer.observe(root===document?document.body:root,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class','aria-busy','aria-pressed','disabled']});
  function guard(event){
    const button=event.target instanceof Element?event.target.closest(selector):null;
    if(!button||!eligible(button))return;
    if(button.classList.contains('v-btn--loading')||button.getAttribute('aria-busy')==='true'){event.preventDefault();event.stopImmediatePropagation();return}
    // Dialogs and responsive layouts may have changed size since registration.
    const state=states.get(button);if(state&&!state.face)state.snapshot=snapshot(button,state.snapshot);
  }
  function settle(){for(const state of [...active]){const snap=state.snapshot;clear(state);if(snap.busy&&state.button.isConnected)holdBusy(state,snap)}}
  root.addEventListener('click',guard,true);document.addEventListener('visibilitychange',settle);reduced.addEventListener('change',settle);
  return {disconnect(){observer.disconnect();for(const state of [...active])clear(state);root.removeEventListener('click',guard,true);document.removeEventListener('visibilitychange',settle);reduced.removeEventListener('change',settle)}};
}
