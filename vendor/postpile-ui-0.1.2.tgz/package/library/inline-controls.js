import {animateLayout,createSearch,createVolume} from './inline-controls-core.js';
window.PostpileInlineControls={animateLayout,createSearch,createVolume};

document.dispatchEvent(new Event('pp-inline-ready'));
