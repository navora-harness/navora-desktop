import { createButtonMenu } from './menu.js';
import { animateMenuSurface, animateMenuLabelReturn, animateMenuPageChange } from './menu-motion.js';
import {menuConfirmation,runMenuAction} from './menu-confirm.js';
import {openNativeDialog,closeNativeDialog,installNativeDialogs} from './native-dialogs.js';
window.PostpileMenus = { createButtonMenu, animateMenuSurface, animateMenuLabelReturn, animateMenuPageChange, menuConfirmation, runMenuAction, openNativeDialog, closeNativeDialog };
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installNativeDialogs,{once:true});else installNativeDialogs();
