/* Optional bootstrap for existing native select markup. */
import('./select-core.js').then(({createSelect})=>{
 const enhance=select=>{if(!select.hasAttribute('data-pp-managed'))createSelect(select)};
 document.querySelectorAll('select').forEach(enhance);
 document.dispatchEvent(new Event('pp-select-ready'));
 new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes){
  if(!(node instanceof Element)||node.closest('.pp-select-menu,.pp-choice-control'))continue;
  if(node.matches('select'))enhance(node);node.querySelectorAll('select').forEach(enhance);
 }}).observe(document.body,{childList:true,subtree:true});
});
