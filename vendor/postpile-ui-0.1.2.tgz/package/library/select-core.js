/* Shared select treatment. Native fields still own values and change events. */
import {mountChoiceLayout,renderChoiceLabel} from './choice-layout.js';
function createRuntime(){
  if(!document.querySelector('link[data-pp-choice-styles]')){
    const css=document.createElement('link');css.rel='stylesheet';css.href=new URL('./choice-select.css',import.meta.url).href;css.dataset.ppChoiceStyles='';document.head.append(css);
  }
  const style=document.createElement('style');
  style.id='pp-select-styles';
  style.textContent=`
  .pp-select-trigger{display:inline-flex;align-items:center;justify-content:space-between;gap:12px;flex:none;box-sizing:border-box;width:var(--pp-select-width,160px);max-width:100%;min-height:38px;padding:7px 11px 7px 12px;border:1px solid rgba(var(--pp-glass-ink),.1);border-radius:11px;background:rgba(var(--pp-glass-rgb),.65);color:var(--text,rgb(var(--pp-glass-ink)));font:inherit;text-align:left;transition:background-color 180ms,border-color 180ms,box-shadow 220ms,transform 220ms cubic-bezier(.22,.75,.2,1)}
  .pp-select-value{overflow:hidden;text-overflow:clip;white-space:nowrap;min-width:0}
  .pp-select-chevron{width:14px;height:14px;flex:none;color:var(--muted);transition:transform 260ms cubic-bezier(.22,.75,.2,1)}
  .pp-select-trigger[aria-expanded=true] .pp-select-chevron{transform:rotate(90deg)}
  .pp-select-trigger:not(:disabled):active{transform:scale(.98)}
  .pp-select-trigger:disabled{opacity:.45;cursor:default}
  .pp-select-trigger:focus-visible{outline:3px solid #438da24d;outline-offset:3px}
  .pp-select-trigger[data-morphing]{opacity:0;pointer-events:none}
  .pp-select-heading{position:absolute;z-index:2;left:6px;right:6px;top:6px;opacity:0;pointer-events:none;display:flex;align-items:center;justify-content:space-between;gap:12px;height:var(--pp-heading-height,24px);box-sizing:border-box;padding:0 5px;white-space:nowrap;overflow:hidden}
  .pp-select-heading span{overflow:hidden;text-overflow:clip}
  .pp-select-heading .pp-select-chevron{transform:rotate(90deg)}
  .pp-select-items{position:relative}
  .pp-select-menu{position:fixed;inset:auto;margin:0;padding:6px;box-sizing:border-box;z-index:2147483000;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:rgba(var(--pp-glass-ink),.23) transparent;border-radius:16px;border:1px solid var(--pp-glass-edge);color:var(--text);font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;background:linear-gradient(145deg,var(--pp-glass-top),var(--pp-glass-bottom)),rgba(var(--pp-glass-rgb),.84);-webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);box-shadow:0 14px 40px #172c4026,0 3px 10px #172c4010,inset 0 1px 0 var(--pp-glass-highlight);opacity:0;transform:translateY(var(--pp-select-offset,-5px)) scale(.965);transition:opacity 180ms ease,transform 260ms cubic-bezier(.22,.75,.2,1)}
  .pp-select-menu[hidden]{display:none!important}
  .pp-select-menu{transform:none;transition:none;opacity:1;background-image:none}
  .pp-select-menu.is-moving{overflow:hidden;pointer-events:none;will-change:left,top,width,height,opacity,filter}
  .pp-select-menu.is-moving .pp-select-option{box-sizing:border-box;width:var(--pp-option-width)}
  .pp-select-menu.is-open{opacity:1;transform:none}
  .pp-select-option{display:grid;grid-template-columns:minmax(0,1fr) 18px;align-items:center;gap:14px;min-height:38px;padding:9px 11px;border-radius:10px;cursor:pointer;user-select:none;font-weight:400;transition:background-color 220ms ease,color 220ms ease,font-weight 220ms ease}
  .pp-select-option:is(.is-active,.is-hovered){background:rgba(var(--pp-glass-ink),.06)}
  .pp-select-option[aria-selected=true]{background:#438da21a;color:var(--pp-popup-accent,#007aff);font-weight:550}
  .pp-select-option[aria-selected=true]:is(.is-active,.is-hovered){background:#438da228}
  .pp-select-option[aria-disabled=true]{opacity:.4;cursor:default}
  .pp-select-option > svg{width:16px;height:16px;color:#438da2;opacity:0}
  .pp-select-option[aria-selected=true] > svg{opacity:1}
  .pp-select-menu[data-scrollable]{scrollbar-gutter:stable}
  .pp-select-menu::-webkit-scrollbar{width:7px;height:7px}
  .pp-select-menu::-webkit-scrollbar-track{background:transparent;margin:10px 0;border-radius:99px}
  .pp-select-menu::-webkit-scrollbar-thumb{min-height:28px;border:2px solid transparent;background:rgba(var(--pp-glass-ink),.26);background-clip:padding-box;border-radius:99px}
  .pp-select-menu::-webkit-scrollbar-thumb:hover{background-color:rgba(var(--pp-glass-ink),.42)}
  .pp-select-menu::-webkit-scrollbar-thumb:active{background-color:rgba(var(--pp-glass-ink),.55)}
  .pp-select-menu::-webkit-scrollbar-button,.pp-select-menu::-webkit-scrollbar-button:single-button{display:none!important;width:0!important;height:0!important;background:transparent}
  @supports selector(::-webkit-scrollbar){.pp-select-menu{scrollbar-width:auto;scrollbar-color:auto}}
  .selection-bar .pp-select-trigger{flex:1;width:auto;min-width:0}
  .selection-bar #selectionAlbum-trigger{grid-column:1/-1}
  @media(max-width:360px){#browseSortSelect-trigger{width:91px;max-width:91px}}
  @media(max-width:600px){.pp-select-trigger{width:min(var(--pp-select-width),150px);min-height:44px;font-size:12px}.pp-select-option{min-height:44px}}
  @media(prefers-reduced-motion:reduce){.pp-select-trigger,.pp-select-chevron,.pp-select-menu,.pp-select-option{transition:none!important}}
  @media(prefers-reduced-transparency:reduce){.pp-select-menu{background:rgb(var(--pp-glass-rgb));backdrop-filter:none;-webkit-backdrop-filter:none}}
  `;
  if(!document.getElementById(style.id))document.head.append(style);
  const controls=new Set(),enhanced=new WeakMap(),reduced=matchMedia('(prefers-reduced-motion: reduce)');let current=null,sequence=0;
  const chevron='<svg class="pp-select-chevron" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 4 4 4-4 4"/></svg>';
  const check='<svg viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4 9 3 3 7-7"/></svg>';
  function sync(control){
    const {select,trigger,value}=control;
    renderChoiceLabel(value,select,select.selectedIndex,control.config,true);trigger.disabled=select.disabled||select.options.length===0;
    const ariaLabel=select.getAttribute('aria-label');if(ariaLabel)trigger.setAttribute('aria-label',ariaLabel);
    renderChoiceLabel(control.heading.querySelector('span'),select,select.selectedIndex,control.config,true);
    control.options.forEach((option,i)=>{option.setAttribute('aria-selected',String(i===select.selectedIndex));option.setAttribute('aria-disabled',String(select.disabled||select.options[i].disabled));renderChoiceLabel(option.firstElementChild,select,i,control.config)});
    if(select.disabled&&current===control)close(false);
    control.layout?.sync();
  }
  function setActive(control,index,keyboard=true){
    control.active=index;
    control.options.forEach((option,i)=>{option.classList.toggle('is-active',i===index&&keyboard);option.classList.toggle('is-hovered',i===index&&!keyboard)});
    const option=control.options[index];
    if(option){control.trigger.setAttribute('aria-activedescendant',option.id);if(keyboard)option.scrollIntoView({block:'nearest'})}
    else control.trigger.removeAttribute('aria-activedescendant');
  }
  function position(control){
    const {trigger,menu}=control,rect=trigger.getBoundingClientRect(),viewport=window.visualViewport;
    // The header becomes the button again at the end of collapse. Keep its
    // typography and text inset identical, including responsive font changes.
    const triggerCss=getComputedStyle(trigger);
    for(const property of ['--pp-glass-rgb','--pp-glass-ink','--pp-glass-edge','--pp-glass-highlight','--pp-glass-top','--pp-glass-bottom'])menu.style.setProperty(property,triggerCss.getPropertyValue(property));
    menu.style.color=triggerCss.color;
    for(const property of ['fontFamily','fontSize','fontWeight','fontStyle','fontStretch','lineHeight','letterSpacing','textTransform','color'])control.heading.style[property]=triggerCss[property];
    control.heading.style.paddingLeft=Math.max(0,parseFloat(triggerCss.paddingLeft)-6)+'px';
    control.heading.style.paddingRight=Math.max(0,parseFloat(triggerCss.paddingRight)-6)+'px';
    const top=viewport?.offsetTop||0,left=viewport?.offsetLeft||0,width=viewport?.width||innerWidth,height=viewport?.height||innerHeight;
    if(rect.bottom<top||rect.top>top+height||!trigger.getClientRects().length){close(false);return}
    for(let ancestor=trigger.parentElement;ancestor&&ancestor!==document.body;ancestor=ancestor.parentElement){
      if(!/(auto|scroll|hidden|clip)/.test(getComputedStyle(ancestor).overflowY))continue;
      const bounds=ancestor.getBoundingClientRect();if(rect.bottom<=bounds.top||rect.top>=bounds.bottom){close(false);return}
    }
    const menuWidth=Math.min(Math.max(rect.width,230),width-24),below=top+height-rect.top-12,above=rect.bottom-top-12;
    menu.style.setProperty('--pp-heading-height',Math.max(0,rect.height-14)+'px');
    stopMotion(control);menu.style.height='';menu.style.width=menuWidth+'px';
    const desired=Math.min(menu.scrollHeight,304),up=below<desired&&above>below,room=Math.max(0,up?above:below),menuHeight=Math.min(desired,room);
    const x=Math.max(left+12,Math.min(rect.right-menuWidth,left+width-menuWidth-12));
    Object.assign(menu.style,{maxHeight:Math.min(room,304)+'px',left:x+'px',top:(up?rect.bottom-menuHeight:rect.top)+'px',transformOrigin:`${Math.max(12,Math.min(menuWidth-12,rect.left+rect.width/2-x))}px ${up?'bottom':'top'}`});
    menu.toggleAttribute('data-scrollable',menu.scrollHeight>menuHeight+1);
    menu.style.setProperty('--pp-select-offset',up?'5px':'-5px');
    const material=getComputedStyle(menu);
    control.destination={left:x+'px',top:(up?rect.bottom-menuHeight:rect.top)+'px',width:menuWidth+'px',height:menuHeight+'px',borderRadius:'16px',opacity:1,filter:'blur(0px)',backdropFilter:'blur(24px) saturate(160%)',backgroundColor:material.backgroundColor,borderColor:material.borderColor,boxShadow:material.boxShadow};
    menu.style.setProperty('--pp-option-width',Math.max(0,menu.clientWidth-12)+'px');
  }
  function frame(control){const css=getComputedStyle(control.menu);return Object.fromEntries(['left','top','width','height','borderRadius','opacity','filter','backdropFilter','backgroundColor','borderColor','boxShadow'].map(key=>[key,css[key]]))}
  function stopMotion(control){control.animation?.cancel();control.contentAnimation?.cancel();control.chevronAnimation?.cancel();control.headingAnimation?.cancel();control.animation=null;control.contentAnimation=null;control.chevronAnimation=null;control.headingAnimation=null;control.menu.classList.remove('is-moving')}
  function origin(control){const r=control.trigger.getBoundingClientRect(),css=getComputedStyle(control.trigger);return {left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px',borderRadius:css.borderRadius,opacity:1,filter:'blur(0px)',backdropFilter:'blur(12px) saturate(160%)',backgroundColor:css.backgroundColor,borderColor:css.borderColor,boxShadow:css.boxShadow}}
  function morph(control,from,to,finish){
    const contentCss=getComputedStyle(control.items),opening=current===control;
    const selected=control.options[control.select.selectedIndex],headingCss=getComputedStyle(control.heading),triggerCss=getComputedStyle(control.trigger),rowCss=getComputedStyle(selected||control.heading);
    const menuCss=getComputedStyle(control.menu),gutter=Math.max(0,control.menu.offsetWidth-control.menu.clientWidth-parseFloat(menuCss.borderLeftWidth)-parseFloat(menuCss.borderRightWidth));
    // Absolutely positioned children share the scrollport's narrower width.
    // Give back its gutter while morphing into the scrollbar-free trigger.
    const buttonText={top:(6+control.menu.scrollTop)+'px',right:(6-gutter)+'px',height:control.menu.style.getPropertyValue('--pp-heading-height'),paddingLeft:Math.max(0,parseFloat(triggerCss.paddingLeft)-6)+'px',paddingRight:Math.max(0,parseFloat(triggerCss.paddingRight)-6)+'px',fontSize:triggerCss.fontSize,fontWeight:triggerCss.fontWeight,lineHeight:triggerCss.lineHeight,opacity:1};
    const rowText={top:(6+(selected?.offsetTop||0))+'px',right:'6px',height:(selected?.offsetHeight||38)+'px',paddingLeft:'11px',paddingRight:'11px',fontSize:rowCss.fontSize,fontWeight:rowCss.fontWeight,lineHeight:rowCss.lineHeight,opacity:0};
    const headingFrom=control.headingAnimation?Object.fromEntries(['top','right','height','paddingLeft','paddingRight','fontSize','fontWeight','lineHeight','opacity'].map(key=>[key,headingCss[key]])):opening?buttonText:rowText;
    const arrow=control.heading.querySelector('svg'),arrowFrom=control.chevronAnimation?getComputedStyle(arrow).transform:`rotate(${opening?0:90}deg)`;
    const contentFrom=control.contentAnimation?{opacity:contentCss.opacity,filter:contentCss.filter,transform:contentCss.transform}:opening?{opacity:0,filter:'blur(9px)',transform:'translateY(-4px)'}:{opacity:1,filter:'blur(0px)',transform:'translateY(0px)'};
    stopMotion(control);
    if(reduced.matches){finish?.();return}
    control.menu.classList.add('is-moving');
    const animation=control.menu.animate([from,to],{duration:380,easing:'cubic-bezier(.22,.75,.2,1)',fill:'both'});control.animation=animation;
    control.contentAnimation=control.items.animate([contentFrom,opening?{opacity:1,filter:'blur(0px)',transform:'translateY(0px)'}:{opacity:0,filter:'blur(9px)',transform:'translateY(-4px)'}],{duration:380,easing:'cubic-bezier(.22,.75,.2,1)',fill:'both'});
    control.chevronAnimation=arrow.animate([{transform:arrowFrom},{transform:`rotate(${opening?90:0}deg)`}],{duration:380,easing:'cubic-bezier(.22,.75,.2,1)',fill:'both'});
    control.headingAnimation=control.heading.animate([headingFrom,opening?rowText:buttonText],{duration:380,easing:'cubic-bezier(.22,.75,.2,1)',fill:'both'});
    animation.finished.then(()=>{if(control.animation!==animation)return;finish?.();stopMotion(control)},()=>{});
  }
  function close(restoreFocus=true){
    if(!current)return;const control=current;current=null;
    control.trigger.setAttribute('aria-expanded','false');control.trigger.removeAttribute('aria-activedescendant');
    const from=frame(control);control.menu.classList.remove('is-open');control.menu.inert=true;control.menu.setAttribute('aria-hidden','true');
    clearTimeout(control.timer);
    const finish=()=>{if(current===control)return;if(typeof control.menu.hidePopover==='function'&&control.menu.matches(':popover-open'))control.menu.hidePopover();control.menu.hidden=true;control.trigger.removeAttribute('data-morphing')};
    if(!control.trigger.getClientRects().length){stopMotion(control);finish()}else morph(control,from,origin(control),finish);
    if(restoreFocus&&!control.trigger.disabled)control.trigger.focus({preventScroll:true});
  }
  function open(control){
    if(control.select.disabled||control.trigger.disabled||control.layout?.display==='expanded')return;
    if(current===control){close();return}
    const from=control.menu.hidden?origin(control):frame(control);
    close(false);clearTimeout(control.timer);current=control;sync(control);
    control.menu.hidden=false;control.menu.inert=false;control.menu.removeAttribute('aria-hidden');
    if(typeof control.menu.showPopover==='function'&&!control.menu.matches(':popover-open'))control.menu.showPopover();
    control.trigger.setAttribute('aria-expanded','true');position(control);if(current!==control)return;
    const selected=control.options[control.select.selectedIndex];
    if(selected&&(selected.offsetTop<control.menu.scrollTop||selected.offsetTop+selected.offsetHeight>control.menu.scrollTop+control.menu.clientHeight-12))control.menu.scrollTop=Math.max(0,selected.offsetTop-(control.menu.clientHeight-selected.offsetHeight)/2);
    control.trigger.setAttribute('data-morphing','');
    void control.menu.offsetWidth;control.menu.classList.add('is-open');
    setActive(control,control.select.selectedIndex,false);control.options.forEach(option=>option.classList.remove('is-hovered'));control.trigger.focus({preventScroll:true});
    morph(control,from,control.destination);
  }
  function commit(control,index){
    if(!control.select.options[index]||control.select.options[index].disabled)return;
    control.select.selectedIndex=index;control.select.dispatchEvent(new Event('input',{bubbles:true}));control.select.dispatchEvent(new Event('change',{bubbles:true}));sync(control);close();
  }
  function move(control,direction){
    const enabled=[...control.select.options].map((option,i)=>option.disabled?-1:i).filter(i=>i>=0),at=enabled.indexOf(control.active);
    setActive(control,enabled[Math.max(0,Math.min(enabled.length-1,(at<0&&direction<0?enabled.length:at)+direction))]??-1);
  }
  function enhance(select,config={}){
    if(enhanced.has(select))return enhanced.get(select).api;
    if(select.closest('.viewer,[data-select-native]')||select.multiple||select.size>1)return;
    if(!select.id)select.id='pp-select-'+(++sequence);
    const width=select.getBoundingClientRect().width,trigger=document.createElement('button'),value=document.createElement('span'),menu=document.createElement('div');
    const label=document.querySelector(`label[for="${CSS.escape(select.id)}"]`);if(label&&!label.id)label.id=select.id+'-label';
    const savedLabelFor=label?.htmlFor;
    trigger.type='button';trigger.className='pp-select-trigger';trigger.id=select.id+'-trigger';trigger.setAttribute('role','combobox');trigger.setAttribute('aria-haspopup','listbox');trigger.setAttribute('aria-expanded','false');trigger.style.setProperty('--pp-select-width',Math.max(140,Math.min(width+24,190))+'px');
    value.className='pp-select-value';value.id=trigger.id+'-value';trigger.append(value);trigger.insertAdjacentHTML('beforeend',chevron);
    if(label){label.htmlFor=trigger.id;trigger.setAttribute('aria-labelledby',label.id+' '+value.id)}
    menu.className='pp-select-menu';menu.id=select.id+'-listbox';menu.setAttribute('role','listbox');menu.setAttribute('popover','manual');menu.hidden=true;if(label)menu.setAttribute('aria-labelledby',label.id);trigger.setAttribute('aria-controls',menu.id);
    const heading=document.createElement('div'),items=document.createElement('div');heading.className='pp-select-heading';heading.setAttribute('aria-hidden','true');heading.innerHTML='<span></span>'+chevron;heading.onclick=()=>close();items.className='pp-select-items';
    const control={select,trigger,value,menu,heading,items,options:[],active:-1,timer:null,search:'',searchAt:0,config};
    function renderOptions(){
      menu.replaceChildren(heading,items);items.replaceChildren();control.options=[...select.options].map((source,i)=>{
        const option=document.createElement('div'),text=document.createElement('span');option.id=menu.id+'-'+i;option.className='pp-select-option';option.setAttribute('role','option');option.setAttribute('aria-disabled',String(source.disabled));text.textContent=source.textContent;option.append(text);option.insertAdjacentHTML('beforeend',check);
        option.addEventListener('pointerdown',event=>{if(event.pointerType==='mouse')event.preventDefault()});
        option.addEventListener('pointermove',event=>{if(event.pointerType==='mouse'&&!source.disabled)setActive(control,i,false)});
        option.addEventListener('pointerleave',()=>option.classList.remove('is-hovered'));
        option.addEventListener('click',()=>{if(!source.disabled)commit(control,i)});items.append(option);return option;
      });control.layout?.render();sync(control);if(current===control){position(control);setActive(control,select.selectedIndex)}
    }
    const savedHidden=select.hidden;
    select.hidden=true;select.after(trigger);(select.closest('dialog')||document.body).append(menu);controls.add(control);enhanced.set(select,control);renderOptions();
    if(select.getAttribute('aria-label'))trigger.setAttribute('aria-label',select.getAttribute('aria-label'));
    if(!label&&!trigger.hasAttribute('aria-label'))trigger.setAttribute('aria-label',select.title||'选择选项');
    items.addEventListener('pointerleave',()=>control.options.forEach(option=>option.classList.remove('is-hovered')));
    trigger.onclick=()=>open(control);
    trigger.onkeydown=event=>{
      if(event.ctrlKey||event.metaKey||event.altKey)return;
      if(['ArrowDown','ArrowUp','Home','End','Enter',' '].includes(event.key)){
        event.preventDefault();event.stopPropagation();
        if(current!==control){open(control);if(event.key==='Home')setActive(control,control.options.findIndex(o=>o.getAttribute('aria-disabled')!=='true'));if(event.key==='End')setActive(control,[...select.options].map((o,i)=>o.disabled?-1:i).filter(i=>i>=0).at(-1)??-1);return}
        if(event.key==='Enter'||event.key===' '){commit(control,control.active);return}
        if(event.key==='Home'){setActive(control,-1);move(control,1)}else if(event.key==='End'){setActive(control,select.options.length);move(control,-1)}else move(control,event.key==='ArrowDown'?1:-1);
      }else if(event.key==='Tab'){if(current===control)close(false)}
      else if(event.key.length===1){event.preventDefault();const now=performance.now();control.search=(now-control.searchAt>600?'':control.search)+event.key.toLocaleLowerCase();control.searchAt=now;if(current!==control)open(control);const index=[...select.options].findIndex(o=>!o.disabled&&o.textContent.trim().toLocaleLowerCase().startsWith(control.search));if(index>=0)setActive(control,index)}
    };
    const abort=new AbortController(),listen={signal:abort.signal};
    select.addEventListener('change',()=>sync(control),listen);select.addEventListener('input',()=>sync(control),listen);
    select.addEventListener('pp-select-sync',()=>sync(control),listen);
    control.observer=new MutationObserver(records=>{if(records.some(r=>r.type==='childList'||r.type==='characterData'||r.attributeName==='data-icon'||r.attributeName==='label'))renderOptions();else sync(control)});control.observer.observe(select,{attributes:true,attributeFilter:['disabled','selected','label','aria-label','data-icon'],subtree:true,childList:true,characterData:true});
    control.layout=mountChoiceLayout(select,trigger,config,{
      pick:index=>commit(control,index),close:()=>{if(current===control){current=null;stopMotion(control);menu.hidden=true;menu.inert=true;if(menu.matches(':popover-open'))menu.hidePopover();trigger.removeAttribute('data-morphing');trigger.setAttribute('aria-expanded','false');trigger.removeAttribute('aria-activedescendant')}},
    });
    let destroyed=false;
    control.api={
      get element(){return control.layout.element},get trigger(){return trigger},get menu(){return menu},
      get display(){return control.layout.display},get isOpen(){return current===control},
      open:()=>{if(!destroyed)open(control)},close:()=>{if(current===control)close()},
      setDisplay:mode=>{if(!destroyed)control.layout.setDisplay(mode)},
      refresh:()=>{if(!destroyed){delete value._ppChoiceKey;delete heading.querySelector('span')._ppChoiceKey;renderOptions();control.layout.measure()}},
      destroy(){if(destroyed)return;destroyed=true;if(current===control)current=null;abort.abort();stopMotion(control);control.observer.disconnect();clearTimeout(control.timer);control.layout.destroy();menu.remove();trigger.remove();select.hidden=savedHidden;if(label&&savedLabelFor!==undefined)label.htmlFor=savedLabelFor;controls.delete(control);enhanced.delete(select)},
    };
    return control.api;
  }

  new MutationObserver(records=>{
    if(records.every(record=>record.target instanceof Element&&record.target.closest('.pp-select-trigger,.pp-select-menu,.pp-choice-control')))return;
    for(const control of controls){
      if(!control.select.isConnected){control.api.destroy()}
      else sync(control);
    }
    if(current&&!current.trigger.getClientRects().length)close(false);

  }).observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['class','hidden','open']});
  document.addEventListener('pointerdown',event=>{if(current&&!event.composedPath().includes(current.menu)&&!event.composedPath().includes(current.trigger))close(false)},true);
  document.addEventListener('keydown',event=>{if(current&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();close()}},true);
  document.addEventListener('click',()=>queueMicrotask(()=>controls.forEach(sync)));
  const reposition=event=>{if(current&&event.target!==current.menu)position(current)};
  window.addEventListener('scroll',reposition,true);window.addEventListener('resize',reposition);window.visualViewport?.addEventListener('resize',reposition);window.visualViewport?.addEventListener('scroll',reposition);
  reduced.addEventListener('change',()=>{if(reduced.matches)controls.forEach(control=>control.animation?.finish())});
  return {enhance};
}
let runtime;
export function createSelect(select,options={}){
 if(!(select instanceof HTMLSelectElement))throw new TypeError('createSelect requires a native select');
 return (runtime??=createRuntime()).enhance(select,options);
}

