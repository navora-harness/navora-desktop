export type ChoiceDisplay='auto'|'expanded'|'collapsed';
export interface ChoiceSelectOptions {
 /** Dropdown by default; filters can opt into auto or expanded. */
 display?:ChoiceDisplay;
 caption?:string;
 /** Viewport breakpoint for auto mode. Default 720 CSS pixels. */
 collapseAt?:number;
 /** Also collapse when the containing area is narrower than this. Default 320. */
 minExpandedWidth?:number;
 container?:HTMLElement;
 /** Return a fresh node each time. Called for rows, current value and segments. */
 renderOption?:(option:HTMLOptionElement,state:{index:number;selected:boolean})=>Node;
}
export interface ChoiceSelect {
 readonly element:HTMLElement;
 readonly trigger:HTMLButtonElement;
 readonly menu:HTMLElement;
 readonly display:'expanded'|'collapsed';
 readonly isOpen:boolean;
 open():void;
 close():void;
 setDisplay(mode:ChoiceDisplay):void;
 refresh():void;
 destroy():void;
}
/** Preserves native select values and input/change events. */
export function createSelect(select:HTMLSelectElement,options?:ChoiceSelectOptions):ChoiceSelect|undefined;
