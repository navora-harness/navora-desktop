export function installGlassButtons(root?: Document | Element): { disconnect(): void }
