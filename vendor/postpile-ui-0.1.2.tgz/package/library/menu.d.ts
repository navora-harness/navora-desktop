export interface ButtonMenu {
  readonly isOpen: boolean;
  open(keyboard?: boolean, last?: boolean): void;
  close(restoreFocus?: boolean): void;
  destroy(): void;
}
/** Opt-in menu. Load menu.css and glass.css; actions remain on native buttons. */
export function createButtonMenu(trigger: HTMLButtonElement, menu: HTMLElement): ButtonMenu;
