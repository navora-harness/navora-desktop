export function animateMenuSurface(el: HTMLElement, anchor: HTMLElement | null | undefined, opening: boolean, done?: () => void): () => void;
export function animateMenuLabelReturn(button: HTMLElement | null, from: DOMRect | null): Animation | null;
export function animateMenuPageChange(panel: HTMLElement, from: DOMRect, contents: HTMLElement | HTMLElement[], title?: HTMLElement | null, origin?: DOMRect | null): Animation[];
