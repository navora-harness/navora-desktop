 const running=new WeakMap();
 const properties=['flexBasis','maxWidth','width','marginLeft','opacity'];
 function frame(el){const css=getComputedStyle(el);return Object.fromEntries(properties.map(key=>[key,css[key]]))}
 function animateLayout(elements,change,options={}){
  const key=elements[0],before=elements.map(frame);running.get(key)?.();change();
  if(options.immediate||matchMedia('(prefers-reduced-motion: reduce)').matches)return ()=>{};
  const after=elements.map(frame),visibility=key.style.visibility;key.style.visibility='visible';
  const motions=elements.map((el,i)=>el.animate([before[i],after[i]],{duration:options.duration||320,easing:'cubic-bezier(.22,.75,.2,1)'}));
  const cancel=()=>{if(running.get(key)!==cancel)return;running.delete(key);motions.forEach(a=>a.cancel());key.style.visibility=visibility};
  running.set(key,cancel);motions[0].finished.then(cancel,cancel);return cancel;
 }
 function create(root,mode){
  const trigger=root.querySelector('[data-inline-trigger]'),content=root.querySelector('[data-inline-content]'),back=root.querySelector('[data-inline-back]'),input=content.querySelector('input');
  const ac=new AbortController(),opts={signal:ac.signal};let opened=false,cancel=()=>{};
  const affected=[content,...root.querySelectorAll('[data-inline-fold]')];if(mode==='search')affected.push(root);else affected.push(trigger);
  const saved={expanded:trigger.getAttribute('aria-expanded'),inert:content.inert,hidden:content.getAttribute('aria-hidden')};
  root.dataset.inlineMode=mode;trigger.setAttribute('aria-expanded','false');content.inert=true;content.setAttribute('aria-hidden','true');
  function setOpen(value,focus=false){
   value=!!value;if(value===opened)return;
   cancel=animateLayout(affected,()=>{opened=value;root.classList.toggle('is-open',opened);trigger.setAttribute('aria-expanded',String(opened));content.inert=!opened;content.setAttribute('aria-hidden',String(!opened));if(mode==='volume'){trigger.inert=opened;root.querySelectorAll('[data-inline-fold]').forEach(el=>el.inert=opened);}});
   if(opened&&focus)input?.focus({preventScroll:true});if(!opened&&content.contains(document.activeElement))trigger.focus({preventScroll:true});
  }
  trigger.addEventListener('click',()=>setOpen(!opened,true),opts);back?.addEventListener('click',()=>setOpen(false),opts);
  root.addEventListener('keydown',e=>{if(e.key==='Escape'&&opened){e.preventDefault();e.stopPropagation();setOpen(false);trigger.focus({preventScroll:true});}},opts);
  document.addEventListener('pointerdown',e=>{if(mode==='volume'&&opened&&!root.contains(e.target))setOpen(false)},opts);
  root.addEventListener('focusout',()=>queueMicrotask(()=>{if(!ac.signal.aborted&&mode==='search'&&opened&&!input.value.trim()&&!root.contains(document.activeElement))setOpen(false)}),opts);
  return {open:()=>setOpen(true,true),close:()=>setOpen(false),toggle:()=>setOpen(!opened,true),get isOpen(){return opened},destroy(){ac.abort();cancel();root.classList.remove('is-open');content.inert=saved.inert;if(saved.expanded==null)trigger.removeAttribute('aria-expanded');else trigger.setAttribute('aria-expanded',saved.expanded);if(saved.hidden==null)content.removeAttribute('aria-hidden');else content.setAttribute('aria-hidden',saved.hidden);trigger.inert=false;root.querySelectorAll('[data-inline-fold]').forEach(el=>el.inert=false);delete root.dataset.inlineMode}};
 }
export {animateLayout};
export function createSearch(root){
 const trigger=root.querySelector('[data-inline-trigger]'),content=root.querySelector('[data-inline-content]'),input=content?.querySelector('input');
 if(!trigger||!content||!input)throw new TypeError('Search needs a trigger and an input');
 const abort=new AbortController(),listen={signal:abort.signal},reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const saved={expanded:trigger.getAttribute('aria-expanded'),inert:content.inert,hidden:content.getAttribute('aria-hidden'),width:content.style.width,visibility:content.style.visibility};
 let opened=false,disposed=false,epoch=0,motions=[];
 root.dataset.inlineMode='search';trigger.setAttribute('aria-expanded','false');content.inert=true;content.setAttribute('aria-hidden','true');
 const viewport=document.createElement('span');viewport.className='pp-search-viewport';content.before(viewport);viewport.append(content);
 const clear=document.createElement('button');clear.type='button';clear.dataset.inlineClear='';clear.setAttribute('aria-label','清空搜索');clear.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 7 10 10M17 7 7 17"/></svg>';root.append(clear);
 const keys=['width','flexBasis','backgroundColor','borderColor','boxShadow'];
 const read=()=>{const css=getComputedStyle(root);return Object.fromEntries(keys.map(key=>[key,css[key]]))};
 function cancel(){motions.forEach(a=>a.cancel());motions=[];content.style.width=saved.width;content.style.visibility=saved.visibility;root.removeAttribute('data-search-moving')}
 function syncValue(){root.toggleAttribute('data-has-value',!!input.value);clear.disabled=!opened||!input.value;clear.tabIndex=opened&&input.value?0:-1}
 function settle(){epoch++;cancel()}
 function setOpen(value,focus=false){
  if(disposed)return;value=!!value;if(value===opened){if(value&&focus)input.focus({preventScroll:true});return}
  const from=read(),fromOpacity=getComputedStyle(content).opacity;cancel();const token=++epoch;
  opened=value;root.classList.toggle('is-open',opened);trigger.setAttribute('aria-expanded',String(opened));content.inert=!opened;content.setAttribute('aria-hidden',String(!opened));syncValue();
  if(opened&&focus)input.focus({preventScroll:true});else if(!opened&&root.contains(document.activeElement))trigger.focus({preventScroll:true});
  const to=read(),width=Math.max(parseFloat(from.width)||0,parseFloat(to.width)||0);
  if(!reduced.matches&&!document.hidden){
   root.setAttribute('data-search-moving','');content.style.visibility='visible';content.style.width=width+'px';
   const timing={duration:opened?360:280,easing:'cubic-bezier(.22,.75,.2,1)',fill:'both'};
   motions=[root.animate([from,to],timing),content.animate([{opacity:fromOpacity,filter:'blur(0px)'},{opacity:opened?1:0,filter:opened?'blur(0px)':'blur(2px)'}],{duration:opened?240:130,easing:'ease-out',fill:'both',delay:opened?45:0})];
   motions[0].finished.then(()=>{if(token===epoch)cancel()},()=>{});
  }
  root.dispatchEvent(new CustomEvent('pp-inline-change',{bubbles:true,detail:{open:opened}}));
 }
 trigger.addEventListener('click',()=>setOpen(!opened,true),listen);
 clear.addEventListener('click',()=>{input.value='';input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));input.focus({preventScroll:true});syncValue()},listen);
 input.addEventListener('input',syncValue,listen);
 root.addEventListener('keydown',event=>{if(event.key==='Escape'&&opened&&!event.isComposing){event.preventDefault();event.stopPropagation();setOpen(false);trigger.focus({preventScroll:true})}},listen);
 root.addEventListener('focusout',()=>queueMicrotask(()=>{if(!disposed&&opened&&!input.value.trim()&&!root.contains(document.activeElement))setOpen(false)}),listen);
 window.addEventListener('resize',settle,listen);document.addEventListener('visibilitychange',settle,listen);reduced.addEventListener('change',settle,listen);
 syncValue();
 return {open:()=>setOpen(true,true),close:()=>setOpen(false),toggle:()=>setOpen(!opened,true),get isOpen(){return opened},destroy(){if(disposed)return;disposed=true;abort.abort();settle();clear.remove();viewport.before(content);viewport.remove();root.classList.remove('is-open');root.removeAttribute('data-has-value');delete root.dataset.inlineMode;content.inert=saved.inert;if(saved.expanded===null)trigger.removeAttribute('aria-expanded');else trigger.setAttribute('aria-expanded',saved.expanded);if(saved.hidden===null)content.removeAttribute('aria-hidden');else content.setAttribute('aria-hidden',saved.hidden)}};
}
export const createVolume=root=>create(root,'volume');
