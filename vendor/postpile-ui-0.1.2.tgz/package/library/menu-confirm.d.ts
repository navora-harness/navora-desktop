export interface MenuConfirmationOptions { title?: string; message: string; confirmText?: string; cancelText?: string; }
export function withMenuConfirmation<T>(present: (options: MenuConfirmationOptions) => Promise<boolean>, action: () => T): T;
export function menuConfirmation(options: MenuConfirmationOptions): Promise<boolean> | null;
export function runMenuAction<T>(menu: HTMLElement, close: () => void, action: () => T, title?: string): T;
export function presentMenuConfirmation(menu: HTMLElement, options: MenuConfirmationOptions, close?: () => void): Promise<boolean>;
