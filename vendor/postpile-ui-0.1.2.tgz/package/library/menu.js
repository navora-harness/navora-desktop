import {prepareSurfaceShadow,animateSurface,surfaceGeometryFrames} from './dialog-motion.js';
/* Opt-in action menu. Existing buttons and action handlers retain ownership. */
const instances=new WeakMap();let current=null,sequence=0;
export function createButtonMenu(trigger,menu){
  if(instances.has(trigger))return instances.get(trigger);
  if(!(trigger instanceof HTMLButtonElement)||!(menu instanceof HTMLElement))throw new TypeError('Expected a button and a menu element');
  const ac=new AbortController(),opts={signal:ac.signal},reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const attributes=['aria-haspopup','aria-expanded','aria-controls'],original=attributes.map(name=>trigger.getAttribute(name));
  const parent=menu.parentNode,next=menu.nextSibling,oldHidden=menu.hidden,oldRole=menu.getAttribute('role'),oldPopover=menu.getAttribute('popover');
  const addedTriggerClass=!trigger.classList.contains('pp-menu-trigger'),addedMenuClass=!menu.classList.contains('pp-menu');
  const originalId=menu.getAttribute('id');
  if(!menu.id)menu.id='pp-menu-'+ ++sequence;
  const oldLabel=menu.getAttribute('aria-label'),oldStyle=menu.getAttribute('style');
  const rowTabIndices=new Map([...menu.querySelectorAll('[role=menuitem]')].map(el=>[el,el.getAttribute('tabindex')]));
  let restoreShadow=null,followFrame=0;
  let opened=false,destroyed=false,version=0,animations=[],active=-1,search='',searchTimer;
  const items=document.createElement('div');items.className='pp-menu-items';items.append(...menu.childNodes);menu.append(items);
  const heading=document.createElement('div');heading.className='pp-menu-origin';heading.setAttribute('aria-hidden','true');menu.append(heading);
  trigger.classList.add('pp-menu-trigger');trigger.setAttribute('aria-haspopup','menu');trigger.setAttribute('aria-controls',menu.id);trigger.setAttribute('aria-expanded','false');
  menu.classList.add('pp-menu');menu.setAttribute('role','menu');menu.setAttribute('popover','manual');menu.hidden=true;
  if(!oldLabel)menu.setAttribute('aria-label',trigger.textContent.trim());
  function rows(){return [...items.querySelectorAll('[role=menuitem]')].filter(el=>el.closest('[role=menu]')===menu&&el.getClientRects().length&&getComputedStyle(el).visibility==='visible')}
  function enabled(){return rows().filter(el=>!el.disabled&&el.getAttribute('aria-disabled')!=='true')}
  function focus(index){const list=enabled();active=(index+list.length)%list.length;list[active]?.focus({preventScroll:true});list[active]?.scrollIntoView({block:'nearest'})}
  function stop(){cancelAnimationFrame(followFrame);followFrame=0;animations.forEach(animation=>animation.cancel());animations=[];restoreShadow?.();restoreShadow=null;menu.classList.remove('is-moving');items.style.width=''}
  const properties=['left','top','width','height','borderRadius','backgroundColor','borderColor','boxShadow'];
  function frame(){const css=getComputedStyle(menu);return Object.fromEntries(properties.map(key=>[key,css[key]]))}
  function origin(){const r=trigger.getBoundingClientRect(),css=getComputedStyle(trigger);return {left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px',borderRadius:css.borderRadius,backgroundColor:css.backgroundColor,borderColor:css.borderColor,boxShadow:css.boxShadow}}
  function place(){
    const r=trigger.getBoundingClientRect(),v=visualViewport,x=v?.offsetLeft||0,y=v?.offsetTop||0,w=v?.width||innerWidth,h=v?.height||innerHeight;
    if(!trigger.getClientRects().length||r.bottom<y||r.top>y+h){close(false);return null}
    const css=getComputedStyle(trigger);
    for(const property of ['--pp-glass-rgb','--pp-glass-ink','--pp-glass-edge','--pp-glass-shadow','--text','--muted'])menu.style.setProperty(property,css.getPropertyValue(property));
    menu.style.width=Math.min(Math.max(r.width,230),w-24)+'px';menu.style.height='';menu.style.maxHeight='304px';
    const desired=Math.min(menu.scrollHeight,304),below=y+h-r.top-12,above=r.bottom-y-12,up=below<desired&&above>below,height=Math.max(0,Math.min(desired,up?above:below));
    Object.assign(menu.style,{left:Math.max(x+12,Math.min(r.right-menu.offsetWidth,x+w-menu.offsetWidth-12))+'px',top:Math.max(y+12,up?r.bottom-height:r.top)+'px',height:height+'px',maxHeight:height+'px'});
    return frame();
  }
  function alignOrigin(){
    // Keep the button content at its real size. The menu scrollport retains a
    // scrollbar gutter while collapsing, and may have been scrolled to the end.
    const rect=trigger.getBoundingClientRect(),css=getComputedStyle(trigger),panel=getComputedStyle(menu);
    const left=parseFloat(css.borderLeftWidth)||0,right=parseFloat(css.borderRightWidth)||0;
    const top=parseFloat(css.borderTopWidth)||0,bottom=parseFloat(css.borderBottomWidth)||0;
    Object.assign(heading.style,{
      left:(left-(parseFloat(panel.borderLeftWidth)||0))+'px',right:'auto',
      top:(menu.scrollTop+top-(parseFloat(panel.borderTopWidth)||0))+'px',bottom:'auto',
      width:Math.max(0,rect.width-left-right)+'px',height:Math.max(0,rect.height-top-bottom)+'px',
      paddingLeft:css.paddingLeft,paddingRight:css.paddingRight,font:css.font,color:css.color,
      gap:css.columnGap,justifyContent:css.justifyContent
    });
  }
  function motion(from,to,opening,done){
    const itemCss=getComputedStyle(items),headingCss=getComputedStyle(heading),itemFrom={opacity:itemCss.opacity,filter:itemCss.filter},headingFrom={opacity:headingCss.opacity};
    stop();const token=++version;
    if(reduced.matches){done();return}
    alignOrigin();
    items.style.width=Math.max(0,menu.clientWidth-(parseFloat(getComputedStyle(menu).paddingLeft)||0)-(parseFloat(getComputedStyle(menu).paddingRight)||0))+'px';
    menu.classList.add('is-moving');
    const timing={duration:380,easing:'cubic-bezier(.22,.75,.2,1)',fill:'both'};
    const soft=menu.getAttribute('data-soft-motion')!=='false';
    const contentFrames=opening?(soft?[itemFrom,{opacity:1,filter:'blur(0px)',offset:.55},{opacity:1,filter:'blur(0px)'}]:[itemFrom,{opacity:1,filter:'blur(0px)'}]):[itemFrom,{opacity:0,filter:soft?'blur(2px)':'blur(4px)',offset:.3},{opacity:0,filter:'blur(0px)',offset:.5},{opacity:0,filter:'blur(0px)'}];
    const originFrames=opening?(soft?[headingFrom,{opacity:0,offset:.3},{opacity:0}]:[headingFrom,{opacity:0}]):[Number(itemFrom.opacity)>.01?{opacity:0}:headingFrom,{opacity:0,offset:.4},{opacity:1,offset:.8},{opacity:1}];
    restoreShadow=prepareSurfaceShadow(menu,from.boxShadow,to.boxShadow);
    animations=[animateSurface(menu,[{...from,'--pp-shadow-progress':0},{...to,'--pp-shadow-progress':1}],timing),items.animate(contentFrames,soft||!opening?{...timing,easing:'linear'}:timing),heading.animate(originFrames,soft||!opening?{...timing,easing:'linear'}:timing)];
    if(!opening){
      const follow=()=>{
        if(token!==version||destroyed||opened||!trigger.isConnected)return;
        animations[0]?.effect?.setKeyframes(surfaceGeometryFrames([from,origin()]));
        alignOrigin();followFrame=requestAnimationFrame(follow);
      };
      followFrame=requestAnimationFrame(follow);
    }
    animations[0].finished.then(()=>{if(token!==version||destroyed)return;stop();done()}).catch(()=>{});
  }
  function open(keyboard=false,last=false){
    if(destroyed||trigger.disabled)return;
    if(opened)return;
    menu.dispatchEvent(new CustomEvent('pp-menu-beforeopen'));
    search='';clearTimeout(searchTimer);
    current?.close(false);current=api;opened=true;
    const fresh=menu.hidden,from=fresh?origin():frame(),itemVisual=getComputedStyle(items),headingVisual=getComputedStyle(heading);
    const contentStart={opacity:itemVisual.opacity,filter:itemVisual.filter},headingStart=headingVisual.opacity;
    stop();
    // Native modal dialogs make body portals inert. Keep this popover in the dialog.
    (trigger.closest('dialog')||document.body).append(menu);menu.hidden=false;menu.inert=false;
    if(!menu.matches(':popover-open'))menu.showPopover();
    trigger.setAttribute('aria-expanded','true');trigger.setAttribute('data-menu-morphing','');
    const css=getComputedStyle(trigger);heading.replaceChildren(...[...trigger.childNodes].filter(node=>!(node instanceof Element&&node.classList.contains('pp-button-face'))).map(node=>node.cloneNode(true)));
    Object.assign(heading.style,{paddingLeft:css.paddingLeft,paddingRight:css.paddingRight,font:css.font,color:css.color,gap:css.columnGap,justifyContent:css.justifyContent,height:Math.max(0,trigger.getBoundingClientRect().height-2)+'px',opacity:'0'});
    rows().forEach(el=>{el.tabIndex=-1;el.classList.remove('is-hovered')});
    const destination=place();if(!destination)return;
    if(menu.hidden)return;
    items.style.opacity=fresh?'0':contentStart.opacity;items.style.filter=fresh?(menu.getAttribute('data-soft-motion')!=='false'?'blur(3px)':'blur(8px)'):contentStart.filter;heading.style.opacity=fresh?'1':headingStart;
    motion(from,destination,true,()=>{items.style.opacity='1';items.style.filter='none';heading.style.opacity='0';if(keyboard)focus(last?enabled().length-1:0)});
    menu.dispatchEvent(new CustomEvent('pp-menu-open'));
  }
  function close(restoreFocus=true){
    if(!opened||destroyed)return;
    const from=frame();opened=false;if(current===api)current=null;trigger.setAttribute('aria-expanded','false');menu.inert=true;
    const finish=()=>{if(opened)return;if(menu.matches(':popover-open'))menu.hidePopover();menu.hidden=true;menu.inert=false;trigger.removeAttribute('data-menu-morphing');items.style.opacity='1';items.style.filter='none'};
    if(!trigger.isConnected||!trigger.getClientRects().length){++version;stop();finish()}else motion(from,origin(),false,finish);
    if(restoreFocus&&trigger.isConnected&&!trigger.disabled)trigger.focus({preventScroll:true});
    menu.dispatchEvent(new CustomEvent('pp-menu-close'));
  }
  trigger.addEventListener('click',()=>opened?close():open(),opts);
  trigger.addEventListener('keydown',event=>{if(['ArrowDown','ArrowUp','Enter',' '].includes(event.key)){event.preventDefault();if(opened)focus(event.key==='ArrowUp'?enabled().length-1:0);else open(true,event.key==='ArrowUp')}if(event.key==='Escape'&&opened){event.preventDefault();event.stopPropagation();close()}},opts);
  menu.addEventListener('toggle',()=>{if(opened&&!menu.matches(':popover-open'))close(false)},opts);
  menu.addEventListener('pointermove',event=>{const row=event.target.closest('[role=menuitem]');rows().forEach(el=>el.classList.toggle('is-hovered',el===row&&!el.disabled&&el.getAttribute('aria-disabled')!=='true'))},opts);
  menu.addEventListener('pointerleave',()=>rows().forEach(el=>el.classList.remove('is-hovered')),opts);
  menu.addEventListener('click',event=>{const row=event.target.closest('[role=menuitem]');if(!opened||!row||!items.contains(row))return;if(row.disabled||row.getAttribute('aria-disabled')==='true'){event.preventDefault();event.stopImmediatePropagation();return}close();},opts);
  menu.addEventListener('keydown',event=>{
    const list=enabled(),index=list.indexOf(document.activeElement);
    if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){event.preventDefault();focus(event.key==='Home'?0:event.key==='End'?list.length-1:index+(event.key==='ArrowDown'?1:-1))}
    else if((event.key==='Enter'||event.key===' ')&&list.includes(document.activeElement)){event.preventDefault();document.activeElement.click()}
    else if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close()}
    else if(event.key==='Tab'){trigger.focus({preventScroll:true});close(false)}
    else if(event.key.length===1&&!event.ctrlKey&&!event.altKey&&!event.metaKey&&event.key!==' '){search+=event.key.toLocaleLowerCase();clearTimeout(searchTimer);searchTimer=setTimeout(()=>search='',600);const next=list.findIndex(el=>(el.querySelector('.pp-menu-label')||el).textContent.trim().toLocaleLowerCase().startsWith(search));if(next>=0){event.preventDefault();focus(next)}}
  },opts);
  document.addEventListener('pointerdown',event=>{if(opened&&!menu.contains(event.target)&&!trigger.contains(event.target))close(false)}, {...opts,capture:true});
  document.addEventListener('focusin',event=>{if(opened&&!menu.contains(event.target)&&!trigger.contains(event.target))close(false)},opts);
  const reposition=event=>{if(!opened||menu.contains(event?.target))return;++version;stop();items.style.opacity='1';items.style.filter='none';heading.style.opacity='0';place()};
  window.addEventListener('resize',reposition,opts);document.addEventListener('scroll',reposition,{...opts,capture:true});visualViewport?.addEventListener('resize',reposition,opts);visualViewport?.addEventListener('scroll',reposition,opts);
  const observer=new MutationObserver(()=>{if(!trigger.isConnected||!menu.isConnected)destroy();else if(trigger.disabled&&opened)close(false)});observer.observe(document,{childList:true,subtree:true,attributes:true,attributeFilter:['disabled']});
  function destroy(){
    if(destroyed)return;close(false);destroyed=true;++version;stop();ac.abort();observer.disconnect();clearTimeout(searchTimer);if(current===api)current=null;
    if(menu.matches(':popover-open'))menu.hidePopover();trigger.removeAttribute('data-menu-morphing');attributes.forEach((name,i)=>original[i]===null?trigger.removeAttribute(name):trigger.setAttribute(name,original[i]));
    if(addedTriggerClass)trigger.classList.remove('pp-menu-trigger');if(addedMenuClass)menu.classList.remove('pp-menu');
    menu.replaceChildren(...items.childNodes);if(oldStyle===null)menu.removeAttribute('style');else menu.setAttribute('style',oldStyle);menu.inert=false;menu.hidden=oldHidden;
    rowTabIndices.forEach((value,el)=>value===null?el.removeAttribute('tabindex'):el.setAttribute('tabindex',value));
    for(const [name,value] of [['id',originalId],['role',oldRole],['popover',oldPopover],['aria-label',oldLabel]])value===null?menu.removeAttribute(name):menu.setAttribute(name,value);
    if(parent?.isConnected)parent.insertBefore(menu,next?.parentNode===parent?next:null);else menu.remove();instances.delete(trigger);
  }
  const api={open,close,destroy,get isOpen(){return opened}};instances.set(trigger,api);return api;
}
