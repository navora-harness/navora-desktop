/* Route an existing confirmation into the menu that initiated the action. */
import {animateMenuLabelReturn,animateMenuPageChange} from './menu-motion.js';
let presenter=null;
export function withMenuConfirmation(present,action){const previous=presenter;presenter=present;try{return action()}finally{presenter=previous}}
export function menuConfirmation(options){return presenter?presenter(options):null}
export function runMenuAction(menu,close,action,title){
 const previous=[...menu.childNodes],source=document.activeElement,label=(title||source?.textContent||'选项').replace('›','').trim();let claimed=false;
 try{return withMenuConfirmation(options=>{claimed=true;return presentMenuConfirmation(menu,options,close)},action)}
 finally{if(!claimed){
  if(menu.isConnected&&previous.some((node,i)=>menu.childNodes[i]!==node)){
   const header=document.createElement('div');header.className='pp-drill-head';const back=document.createElement('button');back.type='button';back.textContent='‹';back.setAttribute('aria-label','返回上一级');const title=document.createElement('strong');title.textContent=label;header.append(back,title);menu.prepend(header);
   const dispose=()=>{menu.removeEventListener('keydown',key,true);menu.removeEventListener('pp-menu-close',dispose);menu.removeEventListener('pp-menu-beforeopen',dispose)};
   const restore=event=>{event?.stopImmediatePropagation();const from=title.getBoundingClientRect();menu.replaceChildren(...previous);dispose();const target=previous.find(node=>node instanceof HTMLElement&&(node===source||node.textContent?.replace('›','').trim()===label));animateMenuLabelReturn(target,from);target?.focus({preventScroll:true})};
   const key=event=>{if(event.key==='Escape'||event.key==='ArrowLeft'){event.preventDefault();restore(event)}};
   back.onclick=restore;menu.addEventListener('keydown',key,true);menu.addEventListener('pp-menu-close',dispose);menu.addEventListener('pp-menu-beforeopen',dispose);back.focus({preventScroll:true});
  }else close();
 }}
}
export function presentMenuConfirmation(menu,options,close=()=>{}){
 menu.dispatchEvent(new CustomEvent('pp-menu-close'));
 menu.getAnimations({subtree:true}).filter(animation=>animation.effect?.getComputedTiming().endTime!==Infinity).forEach(animation=>animation.finish());
 const body=menu.querySelector('.pp-menu-items')||menu,source=document.activeElement;
 const previous=menu.getBoundingClientRect();
 const geometry=['height','max-height','top'].map(key=>[key,menu.style.getPropertyValue(key)]),scroll=menu.scrollTop;
 const stored=document.createDocumentFragment();stored.append(...body.childNodes);
 const role=menu.getAttribute('role'),label=menu.getAttribute('aria-label');menu.setAttribute('role','alertdialog');menu.setAttribute('aria-label',options.title||'确认');
 const view=document.createElement('section');view.className='pp-menu-confirm';
 const title=document.createElement('h3');title.textContent=options.title||'确认';
 const text=document.createElement('p');text.textContent=options.message;
 const actions=document.createElement('div');actions.className='pp-menu-confirm-actions';
 const back=document.createElement('button');back.type='button';back.textContent=options.cancelText||'返回';
 const ok=document.createElement('button');ok.type='button';ok.className='pp-menu-confirm-ok';ok.textContent=options.confirmText||'确认';
 actions.append(back,ok);view.append(title,text,actions);body.append(view);
 menu.style.height='auto';menu.style.maxHeight=Math.max(0,(visualViewport?.height||innerHeight)-24)+'px';menu.scrollTop=0;
 const bounds=menu.getBoundingClientRect(),viewportTop=visualViewport?.offsetTop||0;
 menu.style.top=Math.max(viewportTop+12,Math.min(bounds.top,viewportTop+(visualViewport?.height||innerHeight)-bounds.height-12))+'px';
 let animations=animateMenuPageChange(menu,previous,[]);
 return new Promise(resolve=>{
  let settled=false;
  function finish(value,dismiss=false){
   if(settled)return;
   const from=menu.getBoundingClientRect(),labelFrom=title.getBoundingClientRect();
   settled=true;observer.disconnect();animations.forEach(animation=>animation.cancel());
   menu.removeEventListener('keydown',key,true);menu.removeEventListener('click',click,true);
   menu.removeEventListener('pp-menu-close',outside);menu.removeEventListener('pp-menu-beforeopen',outside);
   const ownsView=view.parentNode===body;
   const returning=ownsView&&!value&&!dismiss;
   if(ownsView){body.replaceChildren(stored);geometry.forEach(([key,value])=>value?menu.style.setProperty(key,value):menu.style.removeProperty(key));menu.scrollTop=scroll}
   if(returning){animations=animateMenuPageChange(menu,from,Array.from(body.children));animateMenuLabelReturn(source,labelFrom)}
   if(ownsView||(menu.getAttribute('role')==='alertdialog'&&menu.getAttribute('aria-label')===(options.title||'确认'))){
    if(role===null)menu.removeAttribute('role');else menu.setAttribute('role',role);
    if(label===null)menu.removeAttribute('aria-label');else menu.setAttribute('aria-label',label);
   }
   if(value)close();else if(!dismiss&&source?.isConnected)source.focus({preventScroll:true});
   resolve(value);
  }
  function outside(){finish(false,true)}
  function click(event){if(!view.contains(event.target))return;event.stopImmediatePropagation();if(event.target.closest('button')===back)finish(false);else if(event.target.closest('button')===ok)finish(true)}
  function key(event){event.stopImmediatePropagation();if(event.key==='Escape'){event.preventDefault();finish(false)}else if(event.key==='Tab'){event.preventDefault();(document.activeElement===back?ok:back).focus()} }
  const observer=new MutationObserver(()=>{if(!menu.isConnected||view.parentNode!==body)finish(false,true)});
  observer.observe(document,{childList:true,subtree:true});
  menu.addEventListener('click',click,true);menu.addEventListener('keydown',key,true);menu.addEventListener('pp-menu-close',outside);menu.addEventListener('pp-menu-beforeopen',outside);back.focus({preventScroll:true});
 });
}
