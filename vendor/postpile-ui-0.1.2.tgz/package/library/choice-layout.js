/* Layout shared by dropdowns and horizontally expanded single-choice filters. */
const modes=new Set(['auto','expanded','collapsed']);
export function renderChoiceLabel(container,select,index,config,caption=false){
 const option=select.options[index],selected=index===select.selectedIndex;
 const key=JSON.stringify([index,option?.label,option?.dataset.icon,selected,caption?config.caption:'']);
 if(container._ppChoiceKey===key)return;
 container._ppChoiceKey=key;container.replaceChildren();
 if(caption&&config.caption){const label=document.createElement('span');label.className='pp-choice-caption';label.textContent=config.caption;container.append(label)}
 const content=document.createElement('span');content.className='pp-choice-label';
 const rendered=option&&config.renderOption?.(option,{index,selected});
 if(rendered instanceof Node)content.append(rendered);
 else {
  if(option?.dataset.icon){const icon=document.createElement('img');icon.src=option.dataset.icon;icon.alt='';icon.className='pp-choice-icon';content.append(icon)}
  const text=document.createElement('span');text.textContent=option?.label||select.dataset.placeholder||'请选择';content.append(text);
 }
 container.append(content);
}
export function mountChoiceLayout(select,trigger,config,actions){
 let mode=config.display||'collapsed';if(!modes.has(mode))throw new TypeError('Unknown select display: '+mode);
 const root=document.createElement('span'),rail=document.createElement('span'),track=document.createElement('span'),pill=document.createElement('span');
 root.className='pp-choice-control';root.dataset.display='collapsed';root.dataset.mode=mode;
 rail.className='pp-choice-rail';track.className='pp-choice-track';track.setAttribute('role','radiogroup');
 track.setAttribute('aria-label',select.getAttribute('aria-label')||config.caption||'筛选');
 pill.className='pp-choice-pill';pill.setAttribute('aria-hidden','true');track.append(pill);rail.append(track);
 trigger.before(root);root.append(rail,trigger);
 const container=config.container||root.closest('[data-choice-container]')||root.parentElement;
 const ac=new AbortController(),listen={signal:ac.signal},reduced=matchMedia('(prefers-reduced-motion: reduce)');
 let buttons=[],display='collapsed',disposed=false,frame=0,layoutMotion=null,pillMotion=null,fadeMotion=null,initialized=false,selected=-2;
 let naturalWidth=0;
 function edges(){
  const max=track.scrollWidth-track.clientWidth;
  root.toggleAttribute('data-scroll-before',track.scrollLeft>1);
  root.toggleAttribute('data-scroll-after',track.scrollLeft<max-1);
 }
 function ensureSelected(behavior='smooth'){
  const button=buttons[select.selectedIndex];if(!button||display!=='expanded')return;
  const center=button.offsetLeft+button.offsetWidth/2;
  const left=Math.max(0,Math.min(track.scrollWidth-track.clientWidth,center-track.clientWidth/2));
  track.scrollTo({left,behavior:reduced.matches?'instant':behavior});
 }
 function indicator(immediate=false){
  const button=buttons[select.selectedIndex],before=getComputedStyle(pill),from={left:before.left,top:before.top,width:before.width,height:before.height};
  pillMotion?.cancel();pillMotion=null;pill.hidden=!button;
  if(!button)return;
  const to={left:button.offsetLeft+'px',top:button.offsetTop+'px',width:button.offsetWidth+'px',height:button.offsetHeight+'px'};
  Object.assign(pill.style,to);
  if(!immediate&&display==='expanded'&&!reduced.matches){
   const animation=pill.animate([from,to],{duration:280,easing:'cubic-bezier(.22,.75,.2,1)'});pillMotion=animation;
   animation.finished.then(()=>{if(pillMotion===animation){animation.cancel();pillMotion=null}},()=>{});
  }
 }
 function sync(){
  if(disposed)return;
  const changed=selected!==select.selectedIndex;selected=select.selectedIndex;
  const tabIndex=!select.disabled&&selected>=0&&!select.options[selected]?.disabled?selected:select.disabled?-1:[...select.options].findIndex(option=>!option.disabled);
  buttons.forEach((button,index)=>{
   button.disabled=select.disabled||select.options[index].disabled;
   button.setAttribute('aria-checked',String(index===selected));button.tabIndex=index===tabIndex?0:-1;
   renderChoiceLabel(button,select,index,config);
  });
  indicator(!changed||!initialized);if(changed)ensureSelected();edges();
 }
 function apply(next){
  if(next===display&&initialized){if(!pillMotion)indicator(true);edges();return}
  const oldWidth=root.getBoundingClientRect().width,focused=root.contains(document.activeElement);
  actions.close();layoutMotion?.cancel();fadeMotion?.cancel();layoutMotion=null;fadeMotion=null;
  display=next;root.dataset.display=next;
  rail.inert=next!=='expanded';rail.setAttribute('aria-hidden',String(next!=='expanded'));
  trigger.inert=next==='expanded';trigger.setAttribute('aria-hidden',String(next==='expanded'));
  const visible=next==='expanded'?rail:trigger,newWidth=root.getBoundingClientRect().width;
  if(initialized&&!reduced.matches){
   layoutMotion=root.animate([{width:oldWidth+'px'},{width:newWidth+'px'}],{duration:300,easing:'cubic-bezier(.22,.75,.2,1)'});
   fadeMotion=visible.animate([{opacity:.25,filter:'blur(2px)'},{opacity:1,filter:'blur(0px)'}],{duration:240,easing:'ease-out'});
   const animation=layoutMotion;animation.finished.then(()=>{if(layoutMotion===animation){animation.cancel();layoutMotion=null;indicator(true);edges()}},()=>{});
  }
  if(focused)(next==='expanded'?buttons[select.selectedIndex]||buttons[0]:trigger)?.focus({preventScroll:true});
  initialized=true;indicator(true);ensureSelected('instant');edges();
 }
 function measure(){
  if(disposed)return;
  // A separate max-content track remains measurable while the dropdown is shown.
  naturalWidth=[...track.children].filter(el=>el!==pill).reduce((sum,el)=>sum+el.getBoundingClientRect().width,0)+Math.max(0,buttons.length-1)*2+8;
  const available=container?.clientWidth||innerWidth,threshold=config.collapseAt??720;
  const next=mode==='auto'?(innerWidth<threshold||available<Math.min(naturalWidth,config.minExpandedWidth??320)?'collapsed':'expanded'):mode;
  apply(next);
 }
 function schedule(){cancelAnimationFrame(frame);frame=requestAnimationFrame(measure)}
 function render(){
  const focused=track.contains(document.activeElement);
  buttons.forEach(button=>button.remove());
  buttons=[...select.options].map((option,index)=>{
   const button=document.createElement('button');button.type='button';button.className='pp-choice-option';button.setAttribute('role','radio');
   button.addEventListener('click',()=>{if(!select.disabled&&!option.disabled)actions.pick(index)});
   button.addEventListener('keydown',event=>{
    if(!['ArrowRight','ArrowLeft','Home','End'].includes(event.key)||event.altKey||event.metaKey||event.ctrlKey)return;
    event.preventDefault();const enabled=buttons.map((b,i)=>b.disabled?-1:i).filter(i=>i>=0),at=enabled.indexOf(index);
    const next=event.key==='Home'?enabled[0]:event.key==='End'?enabled.at(-1):enabled[(at+(event.key==='ArrowRight'?1:-1)+enabled.length)%enabled.length];
    if(next!==undefined){actions.pick(next);buttons[next]?.focus({preventScroll:true});ensureSelected()}
   });track.append(button);return button;
  });sync();measure();if(focused)buttons[select.selectedIndex]?.focus({preventScroll:true});
 }
 track.addEventListener('scroll',edges,{passive:true,signal:ac.signal});
 track.addEventListener('wheel',event=>{
  if(event.ctrlKey||Math.abs(event.deltaX)>Math.abs(event.deltaY)||!event.deltaY)return;
  const delta=event.deltaY*(event.deltaMode===1?24:event.deltaMode===2?track.clientWidth:1),max=track.scrollWidth-track.clientWidth;
  const next=Math.max(0,Math.min(max,track.scrollLeft+delta));
  if(Math.abs(next-track.scrollLeft)>.5){event.preventDefault();track.scrollLeft=next}
 },{passive:false,signal:ac.signal});
 window.addEventListener('resize',schedule,listen);
 reduced.addEventListener('change',()=>{if(reduced.matches){layoutMotion?.finish();pillMotion?.finish();fadeMotion?.finish()}},listen);
 const ro=new ResizeObserver(schedule);ro.observe(container);ro.observe(track);
 document.fonts?.ready.then(()=>{if(!disposed)measure()});
 render();
 return {
  element:root,get display(){return display},sync,render,measure,
  setDisplay(value){if(!modes.has(value))throw new TypeError('Unknown select display: '+value);mode=value;root.dataset.mode=value;measure()},
  destroy(){if(disposed)return;disposed=true;ac.abort();ro.disconnect();cancelAnimationFrame(frame);layoutMotion?.cancel();pillMotion?.cancel();fadeMotion?.cancel();root.before(trigger);root.remove();trigger.inert=false;trigger.removeAttribute('aria-hidden')},
 };
}
