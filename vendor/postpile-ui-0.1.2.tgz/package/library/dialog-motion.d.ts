export function dialogAnchor(): HTMLElement | null;
export function surfaceGeometryFrames(frames: Keyframe[]): Keyframe[];
export function animateSurface(el: HTMLElement, frames: Keyframe[], timing: KeyframeAnimationOptions): Animation;
export function freezeSurfacePosition(el: HTMLElement, box: DOMRect): {left: string; top: string};
export function animateDialogSurface(el: HTMLElement, anchor: HTMLElement | null, opening: boolean, done?: () => void, options?: {duration?: number; menu?: boolean}): () => void;

export function prepareSurfaceShadow(el: HTMLElement, from: string, to: string): () => void;
