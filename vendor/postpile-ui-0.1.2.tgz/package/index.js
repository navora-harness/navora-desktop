export {createButtonMenu} from './library/menu.js';
export {createSelect} from './library/select-core.js';
export {installGlassButtons} from './library/buttons-core.js';
export {animateMenuSurface,animateMenuPageChange,animateMenuLabelReturn} from './library/menu-motion.js';
export {animateDialogSurface,dialogAnchor} from './library/dialog-motion.js';
export {menuConfirmation,presentMenuConfirmation,runMenuAction,withMenuConfirmation} from './library/menu-confirm.js';
export {openNativeDialog,closeNativeDialog} from './library/native-dialogs.js';
export {animateLayout,createSearch as createInlineSearch,createVolume as createInlineVolume} from './library/inline-controls-core.js';
import {installGlassButtons} from './library/buttons-core.js';
const installations=new WeakMap();
/** Install button enhancement only within the selected root. Safe to call again. */
export function installPostpileUI(root=document){
 if(installations.has(root))return installations.get(root);
 const buttons=installGlassButtons(root);
 const instance={destroy(){if(installations.get(root)!==instance)return;buttons.disconnect();installations.delete(root)}};
 installations.set(root,instance);return instance;
}
