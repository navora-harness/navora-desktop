# 行内展开控件

从统一入口导入 `createInlineSearch`、`createInlineVolume`，并导入 `@postpile/ui/styles.css`。控制器返回 `open()`、`close()`、`toggle()`、只读 `isOpen` 与 `destroy()`。支持快速反向切换、Esc、焦点管理和减少动画偏好。示例页的“搜索与音量”使用同一份组件实现。

```html
<div class="pp-inline-control pp-inline-search" id="search">
  <button type="button" data-inline-trigger aria-label="展开搜索">搜索</button>
  <div data-inline-content><input type="search" aria-label="搜索媒体"></div>
</div>
<div class="pp-inline-control pp-inline-volume" id="volume">
  <div data-inline-content>
    <button type="button" data-inline-back aria-label="返回">返回</button>
    <input type="range" min="0" max="100" value="65" aria-label="音量">
    <output>65%</output>
  </div>
  <button type="button" data-inline-trigger aria-label="展开音量">音量</button>
  <button type="button" data-inline-fold>列表</button>
</div>
```

搜索按钮点击展开；空搜索失焦时收起。音量控件在原控制栏内占用空间，暂时折叠 `data-inline-fold` 标记的按钮，点击外部或返回按钮收起。音量与播放器的业务连接由调用方监听原生 `input` 事件，组件不自动修改播放状态。

按钮建议使用示例中的 SVG 图标。媒体库原来的搜索、播放器业务状态保留，不需要为使用示例引入媒体库后端。


搜索外框使用独立的尺寸与材质过渡，输入内容在动效期间固定展开宽度并裁切，放大镜保持原位；快速反向操作从当前画面继续。打开时聚焦输入框，Esc 收起且保留内容，空内容失焦时收起；输入后出现清空按钮，清空后继续输入。可用 `--pp-search-width` 和 `--pp-search-size` 配置展开宽度与按钮尺寸。状态改变时根节点派发 `pp-inline-change`，`event.detail.open` 是当前展开状态。媒体库搜索已接入相同控制器。
