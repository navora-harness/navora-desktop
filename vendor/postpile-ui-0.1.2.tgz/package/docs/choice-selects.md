# 筛选与下拉选择

UI 展台的“筛选与下拉”提供自动、展开、收起三种显示样式和宽栏／窄栏预览。已通过 AppSelect / FilterRadioGroup 接入产品链接库、任务、文件与日志筛选；原生媒体库选择框复用同一套下拉框。

```js
import '@postpile/ui/styles.css';
import {createSelect} from '@postpile/ui';

const source = document.querySelector('#source');
const filter = createSelect(source, {
  display: 'auto',
  caption: '来源',
  collapseAt: 720,
  container: document.querySelector('.filter-area'),
});

filter.setDisplay('expanded'); // 'auto' | 'expanded' | 'collapsed'
// 退出页面：filter.destroy();
```

`collapsed` 是普通下拉框的默认模式，点击后从当前按钮展开选项。`expanded` 始终横向摊开；宽度不足时在组件内部滚动，不显示横向滚动条。两侧渐变透明与轻微模糊只提示对应方向仍有内容，到达边缘后淡出。支持触摸、触控板、鼠标滚轮和方向键；滚到边缘后不拦截页面继续滚动。

`auto` 在窗口小于 `collapseAt`（默认 720 CSS 像素），或容器不足 `minExpandedWidth`（默认 320 CSS 像素，以选项自然宽度为上限）时显示为下拉框，否则展开。`container` 可指定测量区域；也可以给祖先加 `data-choice-container`，默认使用直接父元素。切换模式不改变选中值，并将组件内焦点交给新显示形式。

## 图标与文字

直接在原生选项配置图标地址，当前值、下拉选项、展开项都会显示：

```html
<select id="source" data-pp-managed aria-label="来源筛选">
  <option value="all">全部来源</option>
  <option value="bilibili" data-icon="/icons/bilibili.png">哔哩哔哩</option>
</select>
```

也可以通过 `renderOption(option, {index, selected})` 返回每次新建的 DOM 节点，放置 SVG、图片与文字。每个展示位置单独调用，不能重复返回同一个节点。使用文本节点或 `textContent` 填充外部文字；图标应为空替代文本或 `aria-hidden`，保留可读的选项文字。

原生 `select` 保留值与 `input`／`change` 事件；禁用、异步选项、文本变化会同步。程序直接更改 `select.value` 后可调用 `refresh()`。显式管理的选择框加 `data-pp-managed`，避免同时被 `@postpile/ui/auto` 自动增强。`destroy()` 移除弹层、监听与尺寸观察，恢复原生选择框。

示例使用 UI 库同一套下拉变形动效：展开项选中底板横向移动，模式切换平滑调整宽度；减少动态效果设置下直接切换。
