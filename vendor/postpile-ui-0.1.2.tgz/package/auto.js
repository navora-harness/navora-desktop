/* Optional compatibility bootstrap for existing Postpile markup. */
import './library/buttons.js';
import './library/form-select.js';
import './library/menu-host.js';
import './library/inline-controls.js';
