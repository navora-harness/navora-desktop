export {createButtonMenu} from './library/menu.js';
export {createSelect} from './library/select-core.js';
export type {ChoiceSelect,ChoiceSelectOptions,ChoiceDisplay} from './library/select-core.js';
export {installGlassButtons} from './library/buttons-core.js';
export {animateMenuSurface,animateMenuPageChange,animateMenuLabelReturn} from './library/menu-motion.js';
export {animateDialogSurface,dialogAnchor} from './library/dialog-motion.js';
export {menuConfirmation,presentMenuConfirmation,runMenuAction,withMenuConfirmation} from './library/menu-confirm.js';
export function openNativeDialog(dialog: HTMLDialogElement, anchor?: HTMLElement | null): void;
export function closeNativeDialog(dialog: HTMLDialogElement, finish: () => void): void;
export interface InlineControl {open():void;close():void;toggle():void;readonly isOpen:boolean;destroy():void}
export function createInlineSearch(root: HTMLElement): InlineControl;
export function createInlineVolume(root: HTMLElement): InlineControl;
export function animateLayout(elements:HTMLElement[],change:()=>void,options?:{immediate?:boolean;duration?:number}):()=>void;
export function installPostpileUI(root?: Document | Element): {destroy():void};

export type {ButtonMenu} from './library/menu.js';
export type {MenuConfirmationOptions} from './library/menu-confirm.js';
